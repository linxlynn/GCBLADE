#!/usr/bin/python3
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# purify_genes.py
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#
# Purify all genes in parallel
#
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# 0.1 Parsing arguments
#-------------------------------------------------------------------------------

import argparse
import pickle
import numpy as np
import pandas as pd
import sys
from joblib import Parallel, delayed

import yaml
from itertools import chain
import os
os.environ['OPENBLAS_NUM_THREADS'] = '4'
sys.path.insert(1, 'scripts/OncoBLADE/')
from Deconvolution.OncoBLADE import Purify_AllGenes

def main():
    parser = argparse.ArgumentParser(description="Run Purify_AllGenes")
    parser.add_argument("--pickle_file", type=str, required=True, help="Path to the pickle file from oncoBLADE deconvolution")
    parser.add_argument("--bulk", type=str, required=True, help="Path to the bulk transcriptome files")
    parser.add_argument("--signature", type=str, required=True, help="Path to the signature matrices")
    parser.add_argument("--autogenes", type=str, required=True, help="Path to the selected autogenes")    
    parser.add_argument("--ncores", type=int, required=True, help="Number of cores for parallel processing") # around 20
    parser.add_argument("--output_obj", type=str, required=True, help="Path to save the resulting object")
    args = parser.parse_args()

    # Load the pickle files
    with open(args.pickle_file, 'rb') as f:
        BLADE_output = pickle.load(f)
    with open(args.bulk, "rb") as f:
        bulk_data = pickle.load(f)
    with open(args.signature, "rb") as f:
        signature = pickle.load(f)

    print(type(bulk_data))
    print(bulk_data.keys())
    
    autogenes = pd.read_csv(args.autogenes, sep = '\t')
    valid_genes = autogenes["Unnamed: 0"]
    valid_genes = np.intersect1d(valid_genes, bulk_data['genelist'])
    #valid_genes = np.intersect1d(valid_genes, bulk_data[1])
    valid_genes = valid_genes[valid_genes != "RGS5"]
    
    # Create dfs for input
    Mu = pd.DataFrame(signature['Mu'], index = signature['Genelist'], columns = signature['celltype_list'])
    Omega = pd.DataFrame(signature['Omega'], index = signature['Genelist'], columns = signature['celltype_list'])
    Y = pd.DataFrame(bulk_data['pseudobulk'], bulk_data['genelist'])
    # Y = pd.DataFrame(bulk_data[0], index = bulk_data[1])

    # subset to only use DEG genes
    Mu = Mu.loc[valid_genes,]
    Omega = Omega.loc[valid_genes,]
    Y = Y.loc[valid_genes,]

    # Add small number so Omega values are not zero
    Omega = Omega + 0.01


    samples = list(Y.columns)

    # Run the function
    obj, obj_func = Purify_AllGenes(BLADE_output, Mu.to_numpy(), Omega.to_numpy(), Y.to_numpy(), args.ncores)

    # Save results
    purified = {
        'final_obj': obj,
        'old_obj': BLADE_output['final_obj'],
        'genes_valid': valid_genes,
        'samples': samples,
        'celltype_list': signature['celltype_list']
    }
    with open(args.output_obj, "wb") as outfile:
        pickle.dump(purified, outfile)


if __name__ == "__main__":
    main()
