suppressMessages({
    library(optparse)
    library(dplyr)
    library(ggplot2)
    library(tibble)
    library(scales)
})

# Parse command-line arguments
option_list <- list(
    make_option("--input", type = "character", help = "Loadings file"),
    make_option("--output", type = "character", help = "output folder for bar plots"),
    make_option("--cell_level", type = "character", help = "Specify cell_type or cell_type2")
)

args <- parse_args(OptionParser(option_list = option_list))


# Read StateLoadings (genes x <cell_type>_<state_number>)
W_matrix <- read.csv(args$input, row.names = 1, check.names = FALSE)

# Define cell type colors
if (args$cell_level == "cell_type") {
    Celltype_colors <- data.frame(
        celltype = c("Lymphoid cell", "Epithelial cell", "Mast cell", "Endocrine cell",
                     "Endothelial cell", "Fibroblast", "Macrophage", "Myeloid cell"),
        celltype_color = character(length = 8)
    )
} else {
    Celltype_colors <- data.frame(
        celltype = c("CD4+ T cell", "CD8+ T cell", "DC", "Endocrine cell", "Epithelial cell",
                 "Endothelial cell", "Macrophage M1", "Macrophage M2",
                 "Mast cell", "Memory B cell", "Naive B cell", "NK cell",
                 "Neutrophil", "Plasma cell", "Treg", "iCAF", "myCAF"),
        celltype_color = character(length = 17)
    )
}

tol_colors <- c("#E69F00", "#56B4E9", "#009E73", "#F0E442",
                "#0072B2", "#D55E00", "#CC79A7", "#999999",
                "#CC6677", "#332288", "#DDCC77", "#117733",
                "#88CCEE", "#882255", "#44AA99", "#999933", "#AA4499")

# Extract cell type and state information from column names
States <- data.frame(States = colnames(W_matrix)) %>%
    mutate(celltype = gsub("(_\\d+)$", "", States),
           state_number = gsub(".*_", "", States),
           state_number = as.integer(state_number))


# Ensure output folder exists
if (!dir.exists(args$output)) {
    dir.create(args$output, recursive = TRUE)
}


# Select top 5 genes per state and generate separate plots
nTopGenes <- 50

for (ct in unique(States$celltype)) {
    GeneSelection <- data.frame()
    # Filter states related to this cell type
    cell_states <- States %>% filter(celltype == ct)
    
    for (state in cell_states$States) {
        Genes_to_add <- W_matrix %>%
            rownames_to_column("Gene") %>%
            arrange(desc(get(state))) %>%
            head(nTopGenes) %>%
            mutate(State = state, Loading = .[[state]]) %>%
            select(Gene, State, Loading)

        GeneSelection <- bind_rows(GeneSelection, Genes_to_add)
    }

    # For each state, assign a rank
    GeneSelection <- GeneSelection %>%
        group_by(State) %>%
        arrange(desc(Loading)) %>%
        mutate(Rank = row_number()) #, Loading = rescale(Loading, to = c(0.1,1))) %>%
        # ungroup()

    GeneSelection$Rank <- factor(GeneSelection$Rank, levels = 1:nTopGenes)

    write.csv(GeneSelection, file = file.path(args$output, paste0(ct, "_top50_genes.csv")), row.names = FALSE)

##     # Generate bar plot
##     p <- ggplot(GeneSelection, aes(x = State, y = Loading, fill = Rank)) +  
##     geom_bar(stat = "identity", position = position_dodge(), width = 0.7, color = "black") +
##     geom_text(aes(label = Gene), position = position_dodge(width = 0.7), vjust = -0.5, size = 2.3) +
##     scale_fill_manual(values = tol_colors[1:5]) +
##     labs(title = paste("Top 5 Genes in each state for", ct),
##          x = "States",
##          y = "Loading Coefficient") +
##     theme_minimal() +
##     theme(axis.text.x = element_text(angle = 45, hjust = 1),
##           legend.position = "none")

##     # Save each cell type’s bar plot
##     ggsave(filename = file.path(args$output, paste0(ct, "_barplot.png")), 
##            plot = p, width = 8, height = 6)

}
