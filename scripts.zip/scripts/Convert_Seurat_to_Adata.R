#!/usr/bin/env Rscript
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# Convert_Seurat_to_Adata.R
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#
# Convert seurat from lee et al. to Adata object
# Author: Florenz van Otterloo (f.j.w.vanotterloo@amsterdamumc.nl)
#
# Usage:
# Rscript Convert_Seurat_to_Adata.R \
# -i {input.seurat_object} \
# -o {output.adata_processed} \
#
# TODO:
# History:
# 02-04-2024: Creation
# 25-04-2024: Updated to be intgrated in GCBLADE pipeline
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# 0.1  Import Libraries
#--------------------------------------------------------------------------------

library(dplyr)
library(Seurat)
library(SeuratDisk)
library(optparse)

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# 1.0  Parse snakemake objects 
#--------------------------------------------------------------------------------

option_list = list(
    make_option(c("-i", "--input"), action = "store", default = NA, type = "character", help = "Provide path to file containing Seurat object"),
    make_option(c("-o", "--output"), action = "store", default = NA, type = "character", help = "Provide path to output file")
)

input_file = (parse_args(OptionParser(option_list = option_list)))$input
output_file = (parse_args(OptionParser(option_list = option_list)))$output
output_file = sub("\\.h5ad$", "", output_file)

#--------------------------------------------------------------------------------
# 1.1  load object 
#--------------------------------------------------------------------------------

load(file = input_file)

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# 2.0  inspect object 
#--------------------------------------------------------------------------------

# selecting detailed celltypes and removing apCAF1,2
celltypes <- unique(GC_seuratObj$cell_type2)
celltypes <- celltypes[!celltypes %in% c("apCAF1", "apCAF2")]
celltypes

# select single cells that are apCAF1,2 to be remove
to_remove <- colnames(GC_seuratObj)[!GC_seuratObj$cell_type2 %in% celltypes]
GC_seuratObj_filtered <- GC_seuratObj[,!colnames(GC_seuratObj) %in% to_remove]

# check if all apCAF1,2 are removed
length(colnames(GC_seuratObj_filtered))
unique(GC_seuratObj_filtered$cell_type2)

# rename iCAF1,2,3 to iCAF
GC_seuratObj_filtered$cell_type2[GC_seuratObj_filtered$cell_type2 == "iCAF3"] <- "iCAF"
GC_seuratObj_filtered$cell_type2[GC_seuratObj_filtered$cell_type2 == "iCAF2"] <- "iCAF"
GC_seuratObj_filtered$cell_type2[GC_seuratObj_filtered$cell_type2 == "iCAF1"] <- "iCAF"

# rename myCAF1,2 to myCAF
GC_seuratObj_filtered$cell_type2[GC_seuratObj_filtered$cell_type2 == "myCAF1"] <- "myCAF"
GC_seuratObj_filtered$cell_type2[GC_seuratObj_filtered$cell_type2 == "myCAF2"] <- "myCAF"

# check if renaming was done correct
unique(GC_seuratObj_filtered$cell_type2)

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# 3.0  save object 
#--------------------------------------------------------------------------------
SaveH5Seurat(GC_seuratObj_filtered, filename = output_file)
file_to_convert = paste0(output_file, ".h5seurat")
Convert(file_to_convert, dest = "h5ad")
