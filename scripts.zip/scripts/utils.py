#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# utils.py
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#
# Utils code for DARANA_blade
#
# Author: m.f.b.steketee@amsterdamumc.nl
#
# TODO:
# 1) Generalise is_Downloaded
#
# History:
#  14-9-2022: copied code from https://github.com/jurriaanjanssen/scRNAseq-snakemake/blob/main/scripts/utils.py
#  adjusted Download_Series_Matrix, Get_samples_dict, is_Downloaded, Download_scRNAseq_data ...

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# 0.1  Import Libraries
from glob import glob
import os
import pandas as pd
import json
import itertools
import random
import pickle
#-------------------------------------------------------------------------------
# 1.1 Specify functions
#-------------------------------------------------------------------------------
def Get_samples_dict(config,data_dir):
    """ 
    Obtain dictionary with dataset as key and list of sample accession GEO terms as values
    :param dict  config: configuration file (config.yaml)
    :param str data_dir: data directory
    :returns: dict dataset:samples
    """
    # initialize dict
    Samples_dict = dict()
    # loop over datasets
    for dataset in config["all"]["datasets"]:
        # intialize list
        Samples = []
        # open associated annotation matrix
        with open(data_dir + dataset + "/series_matrix.txt") as infile:
            for line in infile:
                line = line.strip()
                if line.startswith("!Sample_title"):
                    sample_titles = [x.replace('"','') for x in line.split("\t")[1::]]                    
                # if line starts with geo accession field
                elif line.startswith("!Sample_geo_accession"):
                    # parse and split sample names to list
                    GEO_accessions = [x.replace('"','') for x in line.split("\t")[1::]]
            for GEO_accession, sample_title in zip(GEO_accessions, sample_titles):
                    Samples.append("{0}_{1}".format(GEO_accession,sample_title))
        Samples_dict[dataset] = Samples
    return Samples_dict

def Download_Series_matrix(datasets,GSE,data_dir):
    """ 
    Obtain target files for scRNAseq download
    :param list  datasets: Datasets to download
    :param dict GSE: dictionary with dataset as key and GSE as value
    :param str data_dir: data directory path
    :returns: None
    """
    for dataset in datasets:
        # obtain GSE
        GSE_val = GSE[dataset]
        print(GSE_val)
        # create target directory
        os.system("mkdir -p {data_dir}{dataset}/".format(data_dir=data_dir,dataset=dataset))
        # Download data
        os.system("wget -O {data_dir}{dataset}/series_matrix.txt.gz ftp.ncbi.nlm.nih.gov/geo/series/GSE{GSE_short}nnn/GSE{GSE}/matrix/GSE{GSE}_series_matrix.txt.gz".format(data_dir=data_dir,dataset=dataset,GSE=GSE_val,GSE_short = GSE_val[0:3]))
        # unzip
        os.system("gunzip -c {data_dir}{dataset}/series_matrix.txt.gz > {data_dir}{dataset}/series_matrix.txt".format(data_dir=data_dir,dataset=dataset))
        # remove archive
        os.system("rm {data_dir}{dataset}/series_matrix.txt.gz".format(data_dir=data_dir,dataset=dataset))

def get_suffix(dataset):
    """ 
    Obtain suffices of read count file basenames
    :param str dataset: dataset name
    :returns: str : dataset specfic filename prefix
    """
    if dataset == "Kumar":
        return "_gene_cell_exprs_table"

    
def is_Downloaded(Samples_dict,data_dir):
    """ 
    Check if files are downloaded
    :param dict  Samples_dict: Diftonary containing datasets as keys and samplenames as values
    :returns: bool: Bool indicating all files are downloaded
    """
    files_exist = []
    for dataset in Samples_dict:
        # if Chen is downloaded
        if dataset == "Chen" and os.path.isfile(data_dir + "{dataset}/raw_counts/GSM4203181_counts.txt.gz".format(dataset=dataset)):
            return True
        for sample in Samples_dict[dataset]:
            if dataset == 'Kumar':
                sample = sample[0:19]
                if sample[18] == ":":
                    sample = sample[0:18]
            read_counts = data_dir + "{dataset}/raw_counts/single_cell/{sample}_counts.txt.gz".format(data_dir=data_dir,dataset=dataset,sample=sample)
            files_exist.append(os.path.isfile(read_counts))
    return all(files_exist)


def Download_scRNAseq_data(Samples_dict, data_dir):
    """ 
    Obtain target files for scRNAseq download
    :param dict  Samples_dict: Diftonary containing datasets as keys and samplenames as values
    :param str data_dir: data directory path
    :returns: None
    """
    # loop over datasets and samples
    for dataset in Samples_dict:
        # create target directories
        os.system("mkdir -p {data_dir}{dataset}/raw_counts/single_cell".format(data_dir=data_dir,dataset=dataset))
        for sample in Samples_dict[dataset]:
            ## Change sample name for Kumar
            if dataset == 'Kumar':
                sample = sample[0:19]
                if sample[18] == ":":
                    sample = sample[0:18]
            # obtain accession codes
            Main_accession = sample[0:7]
            GEO_Accession = sample.split("_")[0]
            #suffix = get_suffix(dataset)
            # obtain output paths
            out_archive = "{data_dir}{dataset}/raw_counts/single_cell/{sample}_counts.txt.gz".format(data_dir=data_dir,dataset=dataset,sample=sample)
            # obtain ftp link
            ftp = "ftp.ncbi.nlm.nih.gov/geo/samples/{Main_accession}nnn/{GEO_Accession}/suppl/{sample}.csv.gz".format(Main_accession=Main_accession,GEO_Accession=GEO_Accession,sample=sample)
            # Download file
            os.system("wget -O {out_archive} {ftp}".format(out_archive=out_archive,ftp=ftp))

def Get_files(dataset, data_dir):
    return  glob(data_dir + dataset + "/raw_counts/*")

def Get_Target_files_download(Samples_dict,data_dir, dataset):
    """ 
    Obtain target files for scRNAseq download
    :param dict  Samples_dict: Diftonary containing datasets as keys and samplenames as values
    :param str data_dir: data directory path
    :param str dataset: dataset to get target files of
    """
    target_files = []
    if dataset == "Kim":
        target_files.append("{data_dir}{dataset}/raw_counts/GSE131907_Lung_Cancer_raw_UMI_matrix.txt.gz".format(data_dir = data_dir, dataset=dataset))
    elif "/" in dataset:
        pass
    elif dataset == "All":
        return "{data_dir}{dataset}/merged/All_counts.txt".format(data_dir = data_dir, dataset=dataset)
    else:
        for sample in Samples_dict[dataset]:
            path = "{data_dir}{dataset}/raw_counts/{sample}{suffix}".format(data_dir = data_dir, dataset=dataset, sample = sample,suffix = get_suffix(dataset))
            # add paths to list
            target_files.append(path)
    return target_files

def n_sdi(data):
    """
    Taken from: https://gist.github.com/audy/783125#file-shannon-py
    small edit: calculate normalized entropy (divide entropy by maximum entropy (ln(N)))
    Given a hash { 'species': count } , returns the SDI
    
    >>> sdi({'a': 10, 'b': 20, 'c': 30,})
    1.0114042647073518
    """
    from math import log as ln
    def p(n, N):
        """ Relative abundance """
        if n ==  0:
            return 0
        else:
            return (float(n)/N) * ln(float(n)/N)
    N = sum(data.values())
    return -sum(p(n, N) / ln(N) for n in data.values() if n != 0)


def Get_scanpy_env():
    """
    Identify and return scanpy environment
    """
    for env in glob(".snakemake/conda/*.yaml"):
        with open(env) as infile:
            if "scanpy" in infile.read():
                # identify conda environment
                conda_env = env.split(".yaml")[0]
                return conda_env

def Get_singularity_image():
    """
    Identify and return singularity image
    """
    for img in glob(".snakemake/singularity/*.simg"):
        return img

def Get_celltype_dict(datasets,data_dir):
    """
    Create dictionary with detected celltypes in each dataset
    :param list  datasets: Datasets to download
    :param str data_dir: data directory path
    :returns: dict Celltype_dict: dict with dataset as keys and celltypes (set) as values 
    """
    # intialize dict
    Celltype_dict = dict()
    for dataset in datasets:
        # get results of phenotyping
        cluster_phenotypes_path = data_dir + f"{dataset}/results/cluster_phenotypes.json"
        # if phenotyping is not performed give empty entry
        if not os.path.isfile(cluster_phenotypes_path):
            Celltype_dict[dataset] = set()
            continue
        else:
            # read cluster phenotypes
            with open(cluster_phenotypes_path, 'r') as infile:
                cluster_phenotypes = json.load(infile)
            # add all unique entries to dict
            Celltype_dict[dataset] = set(cluster_phenotypes.values())
    return Celltype_dict
        
    
    
def Filter_data(datasets,Celltype_dict, by, data_dir,scanpy_env = "conda", output_dataset = "none"):
    """
    function which calls Find_Cells_to_filter_out.py
    :param list datasets: list of datasets
    :param dict Celltype_dict: dict with dataset as keys and celltypes (set) as values 
    :param str by: field to filter cell by ['n_sdi', celltype']
    :param str output_dataset: output dataset name [default = ""]
    :param str output_dataset: data directory
    """
    # import library
    for dataset in datasets:
        # check if phenotyping is performed already
        if len(Celltype_dict[dataset]) == 0:
            next
        elif not all([os.path.isfile(data_dir + dataset + "/" + x + "/merged/All_counts.txt") for x in Celltype_dict[dataset]]):
            if scanpy_env == "conda":
                import subprocess
                # identify hashed scanpy environment name
                conda_env = Get_scanpy_env()
                # activate scanpy environment locally and run script
                print("Filtering {dataset} counts by {by}...".format(dataset = dataset,by=by))
                os.system('conda run -p {conda_env} python3 ./scripts/Find_Cells_to_filter_out.py -i {input_dataset} -o {output_dataset} -by {by} -dir {data_dir}'.format(conda_env = conda_env, input_dataset = dataset, output_dataset = output_dataset, by=by, data_dir = data_dir))
            elif scanpy_env == "singularity":
                img = Get_singularity_image()
                print("Filtering {dataset} counts by {by}...".format(dataset = dataset,by=by))
                os.system('singularity exec {img} python3 ./scripts/Find_Cells_to_filter_out.py -i {input_dataset} -o {output_dataset} -by {by} -dir {data_dir}'.format(img = img, input_dataset = dataset, output_dataset = output_dataset, by=by, data_dir = data_dir))
        
def Update_datasets(datasets,data_dir,Celltype_dict):
    """
    Update dataset list after filtering
    :param list  datasets: Datasets
    :param dict Celltype_dict: dict with dataset as keys and celltypes (set) as values 
    :returns list new_datasets: Updated dataset list
    """
    # intialize updated list
    new_datasets = []
    for dataset in datasets:
        new_datasets.append(dataset)
        # Check if filtering is performed
        if all([os.path.isfile(data_dir + dataset + "/" + x + "/merged/All_counts.txt") for x in Celltype_dict[dataset]]):
            # add filtered data to updated list
            for celltype in Celltype_dict[dataset]:
                new_datasets.append(dataset + "/" + celltype)
    return new_datasets

def Mix_data(dataset1, dataset2, output_dataset, data_dir):
    """
    function which calls Mix_data.R
    :param str dataset1: dataset1 name
    :param str dataset1: dataset2 name
    :param str output_dataset: output dataset name
    :param str data_dir: data directory
    """
    # only excecute if counts of datasets are merged before and if mixing is not yet performed
    if all([os.path.isfile(data_dir + x + "/merged/All_counts.txt") for x in [dataset1,dataset2]]) and not os.path.isfile(data_dir + output_dataset + "/merged/All_counts.txt"):
        # import library
        import subprocess
        # identify hashed scanpy environment name
        for env in glob(".snakemake/conda/*.yaml"):
            with open(env) as infile:
                if "optparse" in infile.read():
                    # identify conda environment
                    conda_env = env.split(".yaml")[0]
                    break
        # activate scanpy environment locally and run script
        print(f"Merging {dataset1} and {dataset2} datasets...")
        os.system(f'conda run -p {conda_env} Rscript scripts/Mix_data.R --dataset1 {dataset1} --dataset2 {dataset2} -o {output_dataset} -d {data_dir}')

def Remove_cells_from_counts(input_dataset, output_dataset, cells_to_retain,data_dir):
    """
    Find_Cells_to_filter_out.py: Function used to remove cells from All_counts.txt
    :param str input_dataset: input dataset name
    :param str output_dataset: output dataset name
    :param list cell_to_retain: list containing cell barcodes
    :param str data_dir: data directory
    """
    # create output dir
    if not os.path.exists(f"{data_dir}/{input_dataset}/{output_dataset}/merged/"): os.makedirs(f"{data_dir}/{input_dataset}/{output_dataset}/merged/")
    # intialize list with index 0 (GENE)
    indices = [0]
    with open(f"{data_dir}/{input_dataset}/{output_dataset}/merged/All_counts.txt", "w") as outfile:
        # open file
        with open(f"{data_dir}{input_dataset}/merged/All_counts.txt") as infile:
            # get header
            header = infile.readline().strip()
            header_split = header.split("\t")
            # obtain indices of cells to retain
            for cellid in header_split:
                if cellid in cells_to_retain:
                    indices.append(header_split.index(cellid))
            # write header to file
            outfile.write("\t".join([header_split[index] for index in indices]) + "\n")
            # loop over lines
            for line in infile:
                row = line.strip().split("\t")
                # write counts to file
                outfile.write("\t".join([row[index] for index in indices]) + "\n")

def Fetch_DEG_data(adata,key):
    """
    Fetch DEG data from adata.uns
    :param Anndata adata: adata object
    :param str key: key in uns containing data
    :returns: Pandas.DataFrame : dataframe containing DEG results
    """
    result = adata.uns[key]
    groups = result['names'].dtype.names
    DEG_df = pd.DataFrame(
    {'C' + group + '_' + key: result[key][group]
    for group in groups for key in ['names','scores', 'logfoldchanges', 'pvals_adj']})
    return DEG_df

def Retain_raw_highly_variable(adata):
    """
    Subset to adata.raw and to only obtain highly variable genes
    :param str adata: adata object
    :returns: adata : adata object with filtered raw layer
    """
    adata.raw = adata.raw[:,adata.raw.var.highly_variable == True].to_adata()
    return adata

def Retain_highly_variable(adata):
    """
    Subset only highly variable genes
    :param str adata: adata object
    :returns: adata : adata object filtered
    """
    adata = adata[:,adata.var.highly_variable == True]
    return adata

def Get_DEG_target_files(major_datasets, Celltype_dict, DEG_methods, data_dir):
    """
    obtain list of DEG target files
    :param list major_datasets: list of datasets
    :param dict Celltype_dict: dict with dataset as keys and celltypes (set) as values 
    :param list DEOG_methods: list of DEG methods
    :param str data_dir: data directory
    :returns: list files: list of DEG target files
    """
    files = []
    for major_dataset in major_datasets:
        celltypes = Celltype_dict[major_dataset]
        files = files + [data_dir + f"{major_dataset}/results/DEGs/{DEG_method}/DEGs_data_{celltype}.txt" for DEG_method,celltype in itertools.product(DEG_methods,celltypes)]
    return files

def Get_batch_key(dataset):
    """
    obtain var containing batch key
    :param str data_dir: dataset
    :returns: str: batch key
    """
    if dataset == 'All':
        return 'dataset'
    else:
        return 'patient_id'


def Get_Target_plots(datasets,config,extension = "png"):
    """
    Obtain list of target plots
    :param list datasets: datasets
    :param dict config: configuration file
    :returns list plots: list containing target plots
    """
    plots = []
    for dataset in datasets:
        # Add UMAPs to plots (only plot dataset if dataset is not 'All')
        if "All" in dataset: 
            plots += [f'../plots/{dataset}/UMAP/UMAP_{colouring}.{extension}' for colouring in config['UMAP']['colouring']]
        else:
            plots += [f'../plots/{dataset}/UMAP/UMAP_{colouring}.{extension}' for colouring in [x for x in config['UMAP']['colouring'] if x != 'dataset']]
        # add phenotyping dotplots
        plots.append(f'../plots/{dataset}/phenotyping/Dotplot_phenotyping_clusters.{extension}')
        plots.append(f'../plots/{dataset}/phenotyping/Dotplot_phenotyping_celltypes.{extension}')
        if dataset in config['all']['datasets']:
            # add cell fractions barplots
            plots.append(f'../plots/{dataset}/cell_fractions/Cell_fractions.{extension}')
        if dataset.split("/")[-1] in ["T_cell", "Myeloid_cell","All"] or dataset in config['all']['datasets']:
            plots.append(f'../plots/{dataset}/phenotyping/Phenotyping_report.pdf')
    return plots



def Get_fold_patients(adata,fold,seed,max_fold = 5):
    """
    Obtain patients included in test set and training set for a fold
    :param Anndata adata: adata object
    :param int fold: Cross validation fold
    :param int seed: RNG seed
    :param int max_fold: number of folds (default = 10)
    :returns dict patient_dict: dict containing patients included in training/test for a fold
    """
    # Fetch patients
    patient_ids = adata.obs['patient_id'].cat.categories.tolist()
    # shuffle patients
    random.seed(seed)
    random.shuffle(patient_ids)
    # Fetch number of patients included in test set
    n_patients_test = round(len(patient_ids) / max_fold)
    # for now, hard code the size of testset (because rounding happens)
    if n_patients_test > 2:
        n_patients_test -= 1
    # get indices of test samples
    test_ix = range(fold*n_patients_test,fold*n_patients_test+n_patients_test)
    # fetch training and test patients
    train = [patient_ids[i] for i in range(len(patient_ids)) if i not in test_ix]
    test = [patient_ids[i] for i in range(len(patient_ids)) if i in test_ix]
    # store in dict
    patient_dict = {'train' : train, 'test' : test}
    return patient_dict
    
def read_Signature(path):
    """
    Read variance from .pickle file
    :param str path: celltype to path to signature
    :returns np.array variance: celltype variance

    """
    with open(path, 'rb') as infile:
        signature = pickle.load(infile)
    return signature['Var'], signature['Mu'], signature['Omega'], signature['celltype_list'], signature['Genelist'], signature
        
def write_Signature(Signature,NewOmega,out):
    """
    Update Omega in signature
    :param dict Signature: Signature matrices dict
    :param np.array NewOmega: Array containing new Omega matrix
    :param str out: output path

    """
    Signature.update(Omega = NewOmega)
    with open(out, 'wb') as outfile:
        pickle.dump(Signature, outfile)    
    
#-------------------------------------------------------------------------------
# 1.2 Specify Class
#-------------------------------------------------------------------------------

class Assertions_Class:
    """
    Snakemake assertions container
    :param bool Assert_bool: specifies whether assertions should be printed
    :param bool fast: specifies whether long excecution assertions should be skipped
    """
    
    def __init__(self, Assert_bool, Fast):
        self.to_assert = Assert_bool
        self.Fast = Fast
        
    # Check if series matrix file is downloaded
    def Assert_Sample_Overview(self,data_dir):
        if not self.to_assert: pass
        else:
            if not glob(data_dir + "*/series_matrix.txt"):
                print("Series matrices not downloaded yet.\n Downloading series matrix first.\nAfterwards run snakemake again.\n")
                
    # Check how many samples per dataset
    def Assert_Samples(self,Samples_dict,GSE):
        if not self.to_assert: pass
        else:
            for dataset,Samples in Samples_dict.items():
                print("{dataset} et al. Dataset (GSE{GSE}) has {n} samples".format(dataset = dataset,GSE=GSE[dataset], n = str(len(Samples))))

    # Check how many files are downloaded
    def Assert_Download(self,data_dir,Samples_dict):
        if not self.to_assert: pass
        else:
            for dataset in Samples_dict:
                n_downloads=len(glob(data_dir + dataset + "/raw_counts/*"))
                print("{n} files from {dataset} dataset are downloaded and saved in {data_dir}{dataset}/raw_counts/".format(n=n_downloads,dataset=dataset,data_dir=data_dir))

    # Check how many genes per file (only when fast = False)
    def Assert_nGenes(self, data_dir,Samples_dict):
        if not self.to_assert or self.Fast: pass
        else:
            for dataset in Samples_dict:
                nGenes = []
                raw_files = glob(data_dir + dataset + "/raw_counts/*")
                for file in raw_files:
                    with open(file) as infile:
                        nGenes.append(len(infile.readlines()) - 1)
                if len(set(nGenes)) == 1:
                    print("All files in {dataset} have {nGenes} genes.".format(dataset=dataset,nGenes=nGenes[0]))
                else:
                    print("Files in {dataset} have different amount of genes: {nGenes}".format(dataset=dataset,nGenes=nGenes))
