#!/usr/bin/python3
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# BLADE_AutoGeneS.py
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#
# Run BLADE for a given DEG method
#
# Author: Mischa Steketee (m.f.b.steketee@amsterdamumc.nl)
#
# Usage:
"""
python3 scripts/BLADE.py  \
-i_bulk {input.simulated_bulk} \
-i_sign {input.signature_matrices} \
-i_TF {input.tumor_fractions} \
-i_DEGs {input.DEGs_data} \
-DEG_method {wildcards.DEG_method} \
-DEG_order {wildcards.order} \
-Ntop_DEGs {wildcards.Ntop_DEGs} \
-parameters {params.Parameters} \
-cohort {params.cohort} \
-cell_type {wildcards.celltype_level} \
-o {output.BLADE_output} \
"""
#
# TODO:
# 1) print if gene is not in one of either bulk or scRNAseq data & adjust both datasets on that
# 2) genes should actually have the used genes, now uses genes in signature
#
# History:
#  5-10-2022: adapted from https://github.com/jurriaanjanssen/scRNAseq-snakemake 
#  13-10-2022: Add expectation with groups
#  17-7-2022: Add expectation based on cmdline input
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# 0.1  Import Libraries
#-------------------------------------------------------------------------------
import argparse
import pickle
import pandas as pd
import numpy as np
import sys
print(sys.prefix)

import yaml
from itertools import chain
import os
os.environ['OPENBLAS_NUM_THREADS'] = '4'
sys.path.insert(1, 'scripts/OncoBLADE/')
from Deconvolution.OncoBLADE import Framework_Iterative

## function to find indices from matches in a list comparison
def matched_index(l1, l2):
    l2 = set(l2)
    return [i for i, el in enumerate(l1) if el in l2]

def intersection(lst1, lst2):
    lst3 = [value for value in lst1 if value in lst2]
    return lst3
    
#-------------------------------------------------------------------------------
# 1.1 Parse command line arguments
#-------------------------------------------------------------------------------
def parse_args():
    "Parse inputs from commandline and returns them as a Namespace object."
    parser = argparse.ArgumentParser(prog = 'python3 BLADE.py',
        formatter_class = argparse.RawTextHelpFormatter, description =
        '  Create celltype specific signature matrices  ')
    parser.add_argument('-i_bulk', help='path to bulk transcriptome files',
                        dest='input_bulk',
                        type=str)
    parser.add_argument('-i_sign', help='path to signature matrices',
                        dest='input_signature',
                        type=str)
    parser.add_argument('-i_TF', help='path to Expected Tumor fractions',
                        dest='input_TF',
                        type=str)
    parser.add_argument('-i_autogenes', help='path to selected autogenes',
                        dest='input_autogenes',
                        type=str)
    parser.add_argument('-expectation', help='with or without expected tumor fraction',
                        dest='expectation',
                        choices = ['no_expectation','with_expectation'],
                        type=str)
    parser.add_argument('-parameters', help='path to config file',
                        dest='parameters',
                        type=str)
    parser.add_argument('-cohort', help='which bulk cohort',
                        dest='cohort',
                        choices = ['TCGA', 'simulation'],
                        type=str)
    parser.add_argument('-cell_type', help='cell type level',
                        dest='cell_type',
                        choices = ['cell_type', 'cell_type2'],
                        type=str)
    parser.add_argument('-GSE_IDs', help='cell type level',
                        dest='GSE_split',
                        type=str)
    parser.add_argument('-o', help='path to output file',
                        dest='output',
                        type=str)
    args = parser.parse_args()
    return args

args = parse_args()
#-------------------------------------------------------------------------------
# 1.2 Read Parameters
#-------------------------------------------------------------------------------
# read configuration file
with open(args.parameters) as infile:
    config = yaml.load(infile, Loader=yaml.FullLoader)
    
Alpha = config["BLADE"]["Parameters"]["Alpha"]
Kappa0 =  config["BLADE"]["Parameters"]["Kappa0"]
SY = config["BLADE"]["Parameters"]["SY"]
Nrep = config["BLADE"]["Parameters"]["Nrep"]
Nrepfinal = config["BLADE"]["Parameters"]["Nrepfinal"]
Njob = config["BLADE"]["Parameters"]["Njob"]
expectation = args.expectation
cohort = args.cohort
cell_type = args.cell_type
GSE_split = args.GSE_split

if cohort == 'simulation':
    TF_column = '0'
#-------------------------------------------------------------------------------
# 2.1 Read data
#-------------------------------------------------------------------------------
# read bulk data
with open(args.input_bulk, "rb") as infile:
    bulk_data = pickle.load(infile)
# read signatures
with open(args.input_signature, "rb") as infile:
    signature = pickle.load(infile)

#print(bulk_data)

# read GSE_split, if used
GSE_split_used = False
if args.GSE_split:
    GSE_IDs = pd.read_csv(GSE_split)
    selected_IDs = GSE_IDs['x']
    GSE_split_used = True    

    
# read Expected tumor fractions
if cohort == "TCGA":
    Expected_TF = pd.read_csv(args.input_TF, sep = "\t")
elif cohort == 'simulation':
    with open(args.input_TF, "rb") as infile:
        Expected_TF = pickle.load(infile)
        Expected_TF = pd.DataFrame.from_dict(Expected_TF).transpose()
        Expected_TF = Expected_TF.rename(columns=str)
        if GSE_split_used:
            Expected_TF = Expected_TF.loc[selected_IDs]
        print(Expected_TF)


# read selected genes
selected_genes = pd.read_csv(args.input_autogenes, sep = "\t")

#-------------------------------------------------------------------------------
# 2.2 Create DEG indices for Mu, Omega and Y
#-------------------------------------------------------------------------------
genes = selected_genes["Unnamed: 0"]  #selected_genes.index.to_list()
#print(genes)
if cohort == "TCGA":
    #print(selected_genes["Unnamed: 0"])
    #print(signature['Genelist'])
    genes = intersection(genes, bulk_data[1]) ## only needed if bulk_data misses genes that are in signature
    #print(bulk_data[1])
    #print(len(genes))
    genes.remove("RGS5")
elif cohort == "simulation":
    bulk_data = {"pseudobulk":bulk_data['pseudobulk'], "genelist":bulk_data['genelist']}
    #print(bulk_data['genelist'])
    genes = intersection(genes, bulk_data['genelist'])
    #print(genes)
    
##------------------------------------------------------------------------------
# 3.1 Prepare Mu,Omega and Y
#-------------------------------------------------------------------------------
## Create dfs for BLADE input
Mu = pd.DataFrame(signature['Mu'], index = signature['Genelist'], columns = signature['celltype_list'])
Omega = pd.DataFrame(signature['Omega'], index = signature['Genelist'], columns = signature['celltype_list'])
if cohort == "TCGA":
    Y = pd.DataFrame(bulk_data[0], index = bulk_data[1] )
elif cohort == "simulation":
    Y = pd.DataFrame(bulk_data['pseudobulk'], index = bulk_data['genelist'] )
    if GSE_split_used:
        Y = Y[selected_IDs]

## subset to only use DEG genes
Mu = Mu.loc[genes,]
Omega = Omega.loc[genes,]
Y = Y.loc[genes,]

## check if any genes occur twice in Y
#lst = list(Y.index)
#bulk2 = list(set([x for x in lst if lst.count(x)==2]))
#print(bulk2)

#print(Mu.index)
#print(Y.columns)
#print(Expected_TF.index)
#print(Expected_TF) #['sample'])

#print(signature['celltype_list'])

# Sanity checks
if cohort == "TCGA":
    if len(signature['GeneList_hvg']) >= len(signature['Genelist']):
        raise ValueError("Mistake in assigning genelists in Create_signature")
    elif len(bulk_data[1]) != len(bulk_data[0][next(iter(bulk_data[0]))]):
        raise ValueError("Genes do not correspond to their expression levels")
    elif not(any(Mu.index == Y.index)):
        raise ValueError("signature and bulk genes don't align")
    elif 'Expected_TF' in locals(): # only if Expected_TF exists
        if not(any(Expected_TF['sample'] == Y.columns)):
            raise ValueError("Expected tumor fractions and bulk patients don't align")
    else:
        print("Sanity checks passed")
elif cohort == "simulation":
    if len(signature['GeneList_hvg']) >= len(signature['Genelist']):
        raise ValueError("Mistake in assigning genelists in Create_signature")
    elif len(bulk_data['genelist']) != len(bulk_data['pseudobulk'][next(iter(bulk_data['pseudobulk']))]):
        raise ValueError("Genes do not correspond to their expression levels")
    elif not(any(Mu.index == Y.index)):
        raise ValueError("signature and bulk genes don't align")
    elif 'Expected_TF' in locals(): # only if Expected_TF exists
        if not(all(Expected_TF.index == Y.columns)):
            raise ValueError("Expected tumor fractions and bulk patients don't align")
    else:
        print("Sanity checks passed")
        
## Add small number so Omega values are not zero
Omega = Omega + 0.01

#-------------------------------------------------------------------------------
# 3.2 Prepare Alpha0: set Alpha0 to number of obs in signature / 2 for each celltype
#-------------------------------------------------------------------------------
# Intialize Alpha0 (Ngene x Ncell)
Alpha0 = np.empty((len(genes),len(signature['celltype_list'])))
for i,celltype in enumerate(signature['celltype_list']):
    Alpha0[:,i] = signature['celltype_abundances'][celltype] / 2
    
#-------------------------------------------------------------------------------
# 3.3 Prepare Expectation
#-------------------------------------------------------------------------------
# # Intialize Group where 2 celltypes are merged (nGroup x nCelltypes)
# Group = np.zeros((int(len(signature['celltype_list']))-1, len(signature['celltype_list'])))
# # Put epithelial and endothelial cells together in group 0/first group
# for i,celltype in enumerate(signature['celltype_list']):
#       ## Create a identity matrix except for endothelial as its the 6th celltype
#     if celltype == "Endothelial_cell":
#       Group[0,i] = 1
#     elif i > 5:
#       Group[i-1,i] = 1 ## So diagonal continues right after Endothelial_cell
#     else:
#       Group[i,i] = 1

## Try epithelial cells only as tumor fraction
Group = np.identity(len(signature['celltype_list']))

if cohort == "simulation":
    if cell_type == "cell_type":
        tumor_index = signature['celltype_list'].index("Lymphoid cell")
    elif cell_type == "cell_type2":
        tumor_index = signature['celltype_list'].index("Epithelial cell")
        major_cell_types = ['Lymphoid cell', 'Epithelial cell', 'Mast cell', 'Endocrine cell', 'Endothelial cell', 'Fibroblast', 'Macrophage', 'Myeloid cell']
        
        ## Create mapping dict from level 3 back to level 2
        mapping_dict = {'Memory B cell' : 'Lymphoid cell', 'Naive B cell' : 'Lymphoid cell', 'Epithelial cell' : 'Epithelial cell',
                'Mast cell' : 'Mast cell', 'Endocrine cell' : 'Endocrine cell', 'CD4+ T cell' : 'Lymphoid cell',
                'NK cell' : 'Lymphoid cell', 'CD8+ T cell' : 'Lymphoid cell', 'Endothelial cell' : 'Endothelial cell',
                'Treg' : 'Lymphoid cell', 'iCAF' : 'Fibroblast', 'myCAF' : 'Fibroblast', 'Macrophage M2' : 'Macrophage',
                'Macrophage M1' : 'Macrophage', 'Neutrophil' : 'Myeloid cell', 'DC' : 'Myeloid cell', 'Plasma cell' : 'Lymphoid cell'}


        new_columns = {v: 0 for v in set(mapping_dict.values())}
        True_major_cf = pd.DataFrame(new_columns, index=Expected_TF.index)

        # Sum the columns based on the mapping dictionary
        for minor, major in mapping_dict.items():
            True_major_cf[major] += Expected_TF[minor]

        df_estimated_cf = pd.DataFrame(True_major_cf, columns = major_cell_types, index = Y.columns)

        ## set all values to NAN except for the Lymphoid Cell column
        df_estimated_cf.loc[:,df_estimated_cf.columns != "Lymphoid cell"] = float('NAN')
        
        ## Intialize Group where group is 10 celltypes of lower level (nGroup x nCelltypes)
        Group = np.zeros((len(major_cell_types), len(signature['celltype_list'])))     
else:
    tumor_index = signature['celltype_list'].index("Epithelial cell")        
        
if (cohort == "simulation" and cell_type == "cell_type2"):
    for i,celltype in enumerate(signature['celltype_list']):
        ## Get group celltype and its index
        group_celltype = mapping_dict[celltype]
        group_index = major_cell_types.index(group_celltype)

        ## Put detailed subtype in right group
        Group[group_index, i] = 1

    
## Create Expectation matrix (nSample x nGroup)
## initialize with None
if cohort == "TCGA":
    Expectation = np.zeros((len(bulk_data[0]), len(Group))) + np.nan
elif cohort == "simulation":
    Expectation = np.zeros((len(Y.columns), len(Group))) + np.nan
    
# iterate over patients
for i,patient in enumerate(Y.columns):
    # iterate over patients
    # Give patient expected tumor fraction for group 0 (Epithelial cells)
    if cohort == "TCGA":
        Expectation[i,tumor_index] = Expected_TF['ACE'][i]
        if Expected_TF['ACE'][i] == 1:
            Expectation[i,tumor_index] = np.nan
    elif cohort == "simulation":
        if cell_type == "cell_type":
            Expectation[i,tumor_index] = Expected_TF["Lymphoid cell"][i]
        elif cell_type == "cell_type2":
            Expectation = df_estimated_cf.to_numpy()                      

           
## Put Group and expectation in a dict together
Expected = {
      'Group': Group,
      'Expectation': Expectation
}

#-------------------------------------------------------------------------------
# 4.1 Run BLADE
#-------------------------------------------------------------------------------
## run with or without expectation based on cmdline
if expectation == "no_expectation":
  Expected = None


print(Mu)
print(Omega)
print(Y)
print(Expected)
# Run BLADE

#print(BREAK_POINT)

final_obj, best_obj, best_set, outs = Framework_Iterative(
            Mu.to_numpy(), Omega.to_numpy(),Y.to_numpy(),
            Alpha=Alpha, Alpha0=Alpha0, 
            Kappa0=Kappa0, sY=SY,
            Nrep=Nrep, Njob=Njob, IterMax=Nrepfinal, Expectation = Expected)

BLADE_output = {
    'final_obj': final_obj,
    'best_obj': best_obj,
    'best_set': best_set,
    'outs' : outs,
    'genes' : genes
}

#-------------------------------------------------------------------------------
# 5.1 Write to file
#-------------------------------------------------------------------------------
with open(args.output, "wb") as out:
    pickle.dump(BLADE_output, out)
