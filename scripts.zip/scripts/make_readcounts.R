#!/usr/bin/env Rscript
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# make_readcounts.R
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#
# Combine RNAseq data from the TCGA_STAD cohort into a single table 
# Author: Florenz van Otterloo (f.j.w.vanotterloo@amsterdamumc.nl)
#
# Usage:
# Rscript make_readcounts.R -i<path/to/RNAseq_data> -o{output_file}
# 
#
# TODO:
# 1) make output file
# History:
# 01-03-2024: Creation
# 19-04-2024: updated to select specific gender or subtype
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# 0.1  Import Libraries
#-------------------------------------------------------------------------------
suppressWarnings(library(tidyverse))
suppressWarnings(library(readr))
suppressWarnings(library(data.table))
library(optparse)
#-------------------------------------------------------------------------------
# 0.2 Define generate_count_matrix
#-------------------------------------------------------------------------------
generate_count_matrix <- function(files) {
    mat = as.data.frame(do.call(cbind, lapply(files, function(x) fread(x, stringsAsFactors = FALSE))))
    mat <- mat[-c(1:4),]
    gene_names <- mat[,2]
    rownames(mat) <- mat[,1]
    mat <- as.data.frame(mat[, seq(4, ncol(mat), 9)])
    mat <- cbind(gene_names, mat)
    return(mat)
}
#-------------------------------------------------------------------------------
# 1.1 Parse snakemake objects
#-------------------------------------------------------------------------------
option_list = list(
    make_option(c("-i", "--input"), action = "store", default = NA, type = 'character', help = "Provide path to file containing TCGA_STAD barcodes"),
    make_option(c("--subtype_sheet"), action = "store", default = NA, type = 'character', help = "Provide path to file with TCGA patient barcodes and their corresponding molecular subtype"),
    make_option(c("--gdc_samplesheet"), action = "store", default = NA, type = 'character', help = "Provide path to gdc samplesheet"),
    make_option(c("--ACE_samplesheet"), action = "store", default = NA, type = 'character', help = "Provide path to ACE tumor estimates"),
    make_option(c("--input_dir"), action = "store", default = NA, type = 'character', help = "Provide path to input data directory"),
    make_option(c("--subtype"), action = "store", default = NA, type = 'character', help = "Specify subtype to include"),
    make_option(c("--gender"), action = "store", default = NA, type = 'character', help = "Specify gender to include"),
    make_option(c("-o", "--output"), action = "store", default = NA, type = 'character', help = "Provide path to save readcounts matrix"),
    make_option(c("--tumor_fractions"), action = "store", default = NA, type = 'character', help = "Provide path to save samplesheet with selected patients and their ACE estimated tumor fraction")
)

clinical_patient_stad = (parse_args(OptionParser(option_list = option_list)))$input
subtype_sheet = (parse_args(OptionParser(option_list = option_list)))$subtype_sheet
gdc_samplesheet = (parse_args(OptionParser(option_list = option_list)))$gdc_samplesheet
ACE_samplesheet = (parse_args(OptionParser(option_list = option_list)))$ACE_samplesheet
input_dir = (parse_args(OptionParser(option_list = option_list)))$input_dir
subtype = (parse_args(OptionParser(option_list = option_list)))$subtype
gender = (parse_args(OptionParser(option_list = option_list)))$gender
output_file = (parse_args(OptionParser(option_list = option_list)))$output
tumor_fractions = (parse_args(OptionParser(option_list = option_list)))$tumor_fractions

#-------------------------------------------------------------------------------
# 2.1 select patient population based on subtype and sex
#-------------------------------------------------------------------------------

patient_data <- read.delim(clinical_patient_stad, header = TRUE)
# select only non metastatic patients
patient_data <- patient_data[patient_data$ajcc_metastasis_pathologic_pm == "M0",]
# select sex
if (gender == "MALE"){
    patient_data <- patient_data[patient_data$gender == "MALE",]
} else if (gender == "FEMALE"){
    patient_data <- patient_data[patient_data$gender == "FEMALE",]
} 

# select molecular subtype
subtype_sheet <- read.csv(subtype_sheet, header = TRUE)
if (subtype == "MSI"){
    subtype_sheet <- subtype_sheet[subtype_sheet$Subtype == "STAD_MSI",]
} else if (subtype == "CIN"){
    subtype_sheet <- subtype_sheet[subtype_sheet$Subtype == "STAD_CIN",]
} else if (subtype == "GS"){
    subtype_sheet <- subtype_sheet[subtype_sheet$Subtype == "STAD_GS",]
} else if (subtype == "EBV"){
    subtype_sheet <- subtype_sheet[subtype_sheet$Subtype == "STAD_EBV",]
}

patient_data <- patient_data[patient_data$bcr_patient_barcode %in% subtype_sheet$Patient.ID,]   
patient_IDs <- c(patient_data$bcr_patient_barcode)
patient_data_subset <- patient_data[, c("bcr_patient_barcode", "gender")]

#-------------------------------------------------------------------------------
# 2.2 Read RNAseq files into combined matrix
#-------------------------------------------------------------------------------

gdc_samplesheet <- read.table(gdc_samplesheet, header = T, sep = "\t")
gdc_samplesheet <- gdc_samplesheet[gdc_samplesheet$Case.ID %in% c(patient_IDs),]

cwd <- getwd()
setwd(input_dir)
in_dir <- getwd()

file_names <- list.files(in_dir, "\\.rna_seq.augmented_star_gene_counts.tsv$",
                         full.names = FALSE, recursive = TRUE, include.dirs = FALSE)
files_to_read <- paste(gdc_samplesheet$File.ID, gdc_samplesheet$File.Name, sep = '/')
file_names <- file_names[file_names %in% c(files_to_read)]

readcounts <- generate_count_matrix(file_names)

#-------------------------------------------------------------------------------
# 2.3 Rename colnames to patient IDs
#-------------------------------------------------------------------------------

file_names <- sub(".*/", "", file_names)
gdc_samplesheet <- gdc_samplesheet[match(file_names, gdc_samplesheet$File.Name),]
colnames(readcounts)[2:length(readcounts)] <- gdc_samplesheet$Sample.ID

#-------------------------------------------------------------------------------
# 2.4 Identify all samples that are from a tumor 
#-------------------------------------------------------------------------------

meta <- subset(gdc_samplesheet, select=c(Sample.ID, Sample.Type))
tumor_ID <- c(meta$Sample.ID[meta$Sample.Type == "Primary Tumor"], "gene_names")
readcounts <- readcounts[names(readcounts)[names(readcounts) %in% tumor_ID]]

# remove primary suffix from columnname
col_names <- colnames(readcounts)
new_col_names <- c(col_names[1], substr(col_names[-1], 1, nchar(col_names[-1]) - 4))
colnames(readcounts) <- new_col_names

#-------------------------------------------------------------------------------
# 2.5 remove any row from readcounts that has only zero values
#-------------------------------------------------------------------------------

rows_to_remove <- c()

for (row_name in rownames(readcounts)){
    if (sum(readcounts[row_name,-1]) == 0){
        rows_to_remove <- c(rows_to_remove, row_name)
    }
}

readcounts <- readcounts[!(row.names(readcounts) %in% rows_to_remove),]
readcounts_ID_list <- colnames(readcounts)[2:ncol(readcounts)]

#-------------------------------------------------------------------------------
# 2.6 order ACE_samplesheet in the same way as readcounts
#-------------------------------------------------------------------------------
setwd(cwd)
ACE_samplesheet <- read.table(ACE_samplesheet, header = TRUE, sep = "\t")
ACE_samplesheet <- ACE_samplesheet[ACE_samplesheet$sample %in% readcounts_ID_list,]

patient_data_subset <- patient_data_subset[patient_data_subset$bcr_patient_barcode %in% readcounts_ID_list,]
ACE_samplesheet <- merge(ACE_samplesheet, patient_data_subset, by.x = "sample", by.y = "bcr_patient_barcode")

ACE_samplesheet$custom_order <- match(ACE_samplesheet$sample, readcounts_ID_list)
ACE_samplesheet <- ACE_samplesheet[order(ACE_samplesheet$custom_order),]
ACE_samplesheet$custom_order <- NULL

#sanity check
print("sanity checks for")
print(gender)
print(subtype)
if (length(readcounts_ID_list) == length(ACE_samplesheet$sample)){
    print("even number in readcounts and ACE samplesheet")
} else {
    print("WARNING, WARNING WARNING")
    print("READCOUNTS AND ACE ARE NOT EQUAL LENGTHS!!!")
}

ACE_samplesheet$sample <- gsub("-",".", ACE_samplesheet$sample)
print(ACE_samplesheet)

#-------------------------------------------------------------------------------
# 3.1 write to file 
#-------------------------------------------------------------------------------
write.table(readcounts, file = output_file, sep = "\t")
write.table(ACE_samplesheet, file = tumor_fractions, sep = "\t", row.names = FALSE)
