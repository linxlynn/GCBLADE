#!/usr/bin/env Rscript
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# analyze_difference.R
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#
# compare normalized mean cell fractions between STAD_{subtype} and {subtype} across 10 runs
#
# Usage:
# R analyze_difference.R
#
#
#
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# 0.1  Import Libraries
#-------------------------------------------------------------------------------

suppressMessages({
    library(tidyr)
    library(dplyr)
    library(optparse)
    library(ggplot2)
    library(blandr)
    library(ggpubr)
    library(effsize)
})

option_list <- list(
    make_option("--file1", type="character", help="Provide path to normalized combined STAD_{subtype} file"),
    make_option("--file2", type="character", help="Provide path to normalized combined {subtype} file"),
    make_option("--subtype", type="character", help="Specify the {subtype}"),
    make_option("--boxplot", type="character", help="Provide path to box plots"),
    # make_option("--baplot", type="character", help="Provide path to bland altman plots"),
    make_option("--summary", type="character", help="Provide path to statistical summary")
)

args <- parse_args(OptionParser(option_list=option_list))

file1 <- args$file1
file2 <- args$file2
subtype <- args$subtype
boxplot <- args$boxplot
# baplot <- args$baplot
summary <- args$summary

# Create output directories if they don't exist
# dir.create(args$baplot, showWarnings = FALSE, recursive = TRUE)

#-------------------------------------------------------------------------------
# 2.0 Compare mean between STAD_subtype and independent subtype
#-------------------------------------------------------------------------------

# Load file
file_1 = read.csv(file1)
file_2 = read.csv(file2)

cell_types <- c("Lymphoid.cell", "Mast.cell", "Endocrine.cell",
                "Endothelial.cell", "Fibroblast", "Macrophage", "Myeloid.cell")

analyze_cell_type <- function(file1, file2, cell_type) {
    # Create matched data frame
    matched_data <- data.frame(
        data1 = file1[[cell_type]],
        data2 = file2[[cell_type]],
        barcode = file1$barcode
    )
    
    # Calculate basic statistics
    stats <- matched_data %>%
        summarize(
            mean_data1 = mean(data1),
            mean_data2 = mean(data2),
            median_data1 = median(data1),
            median_data2 = median(data2),
            sd_data1 = sd(data1),
            sd_data2 = sd(data2),
            mean_diff = mean_data2 - mean_data1,
            sd_diff = sd_data2 - sd_data1
        )
    
    
    # Statistical test
    wilcox_result <- wilcox.test(matched_data$data1, matched_data$data2, paired = TRUE)
    t_two_sided <- t.test(matched_data$data1, matched_data$data2, paired = TRUE)
    t_one_sided <- t.test(matched_data$data1, matched_data$data2, alternative = "less", paired = TRUE)
    cliff_d <- cliff.delta(matched_data$data1, matched_data$data2)

    ## # Bland-Altman plot
    ## ba_plot <- blandr.draw(matched_data$data1, matched_data$data2,
    ##                        method1name = "File 1", method2name = "File 2",
    ##                        plotTitle = paste("Bland-Altman Plot for", cell_type)
    ##                        ) +
    ##     labs(x = "Mean of 2 files",
    ##          y = "Difference between 2 files")
    
    return(list(
        statistics = stats,
        wilcox_test = wilcox_result,
        t_test_two = t_two_sided,
        t_test_one = t_one_sided,
        cliff_delta = cliff_d
        # bland_altman_plot = ba_plot
    ))
}

# Create combined data for box plot
combined_data <- data.frame()
pvalues <- data.frame()

for (ct in cell_types) {
    temp_data <- data.frame(
        cell_type = ct,
        fraction = c(file_1[[ct]], file_2[[ct]]),
        dataset = rep(c(paste0("STAD_", subtype), subtype), each = nrow(file_1)),
        barcode = rep(file_1$barcode, 2)
    )
    combined_data <- rbind(combined_data, temp_data)

}

# Box plot
max_by_celltype <- combined_data %>%
    group_by(cell_type) %>%
    summarize(y_pos = max(fraction) * 1.2, .groups = "drop")

box_plot <- ggplot(combined_data, aes(x = cell_type, y = fraction, fill = dataset)) +
    geom_boxplot(position = position_dodge(width = 0.8), alpha = 0.7) +
    ## stat_compare_means(aes(group = dataset),
    ##                    method = "wilcox.test", 
    ##                    paired = TRUE,
    ##                    label.y = max_by_celltype$y_pos,
    ##                    label = "p.signif",
    ##                    hide.ns = TRUE) +
    labs(title = "Comparison of normalized mean cell type fractions across 10 runs",
        x = "Cell Type",
        y = "Fraction",
        fill = "Dataset") +
    theme_bw() +
    theme(axis.text.x = element_text(angle = 45, hjust = 1),
        legend.position = "top")

# Save box plot
ggsave(boxplot, box_plot, width = 8, height = 6)


# Save other plots and summary
results <- list()
summary_stats <- data.frame()

for (ct in cell_types) {
    # Analyze
    results[[ct]] <- analyze_cell_type(file_1, file_2, ct)
    
    # Add to summary statistics
    summary_stats <- bind_rows(
        summary_stats,
        results[[ct]]$statistics %>%
            mutate(
                cell_type = ct,
                wilcox_pvalue = results[[ct]]$wilcox_test$p.value,
                t_two_p = results[[ct]]$t_test_two$p.value,
                t_one_p = results[[ct]]$t_test_one$p.value,
                delta = results[[ct]]$cliff_delta$estimate,
                cliff_magnitude = results[[ct]]$cliff_delta$magnitude
            )
    )
    
    ## # Save plots
    ## ggsave(file.path(baplot, paste0("bland_altman_", ct, ".jpg")), results[[ct]]$bland_altman_plot, width = 8, height = 6)
}

# Save summary statistics
write.csv(summary_stats, summary, row.names = FALSE)
