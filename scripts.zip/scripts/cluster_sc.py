#!/usr/bin/env python3

import os
import sys
import pandas as pd
import pickle
import argparse
from scipy.stats import zscore
import scanpy as sc
import matplotlib.pyplot as plt
import numpy as np
from scipy.sparse import issparse

from StateDiscovery.cNMF import StateDiscovery_FrameWork
import StateDiscovery.cNMF
from StateDiscovery.lib.pymf import cnmf

script_dir = "/net/beegfs/cfg/tgac/xlin/florenz_copy/GCBLADE/scripts/OncoBLADE/"
sys.path.insert(0, script_dir)
import Deconvolution.OncoBLADE

def reprocess_adata_subset_scANVI(
        adata,
        *,
        n_neighbors=10,
        leiden_res=1,
        use_rep="X_scANVI",
        
        neighbors_kws=None,
    ):
        """
        Recompute UMAP and leiden on a adata subset when scVI is used (no additional
        batch correction)
        taken from: https://github.com/icbi-lab/luca/blob/master/lib/scanpy_helper_submodule/scanpy_helpers/annotation.py
        """
        
        if use_rep == 'X_pca':
                X_before = adata.X.toarray() if issparse(adata.X) else adata.X
                # print("Before scaling - NaN count:", np.isnan(X_before).sum())
                variances = np.var(X_before, axis=0)
                # print("Minimum variance before scaling:", np.min(variances))
                # print("Number of near-zero variances (e.g., <1e-12):", np.sum(variances < 1e-12))
                # print("Any negative variances:", np.any(variances < 0))

                threshold = variances >= 1e-6
                adata = adata[:, threshold].copy()

                sc.pp.scale(adata, max_value=10)

                # X_after = adata.X.toarray() if issparse(adata.X) else adata.X
                # print("After scaling - NaN count:", np.isnan(X_after).sum())

                sc.pp.pca(adata, svd_solver='arpack')
                
        neighbors_kws = {} if neighbors_kws is None else neighbors_kws
        sc.pp.neighbors(
            adata, use_rep=use_rep, n_neighbors=n_neighbors, **neighbors_kws
        )
        sc.tl.umap(adata)

def safe_zscore(X, epsilon=1e-6, axis=0):
    """
    Compute the z-score along the specified axis, adding epsilon to avoid division by zero.
    """
    mean = np.mean(X, axis=axis, keepdims=True)
    std = np.std(X, axis=axis, keepdims=True)
    return (X - mean) / (std + epsilon)

adata = sc.read("/net/beegfs/cfg/tgac/xlin/florenz_copy/GCBLADE/data/Lee/results/adata_phenotyped_detailed.h5ad")
# print(adata.obs["cell_type2"].unique())
# print(adata.obs["patient"])

sub_info = pd.read_csv("/net/beegfs/cfg/tgac/xlin/florenz_copy/GCBLADE/data/Lee/sc_subtype_mapping/updated_single_cell_atlas.csv")  # Your external file
sub_info = sub_info.set_index("ID")
adata.obs["mol_subtype"] = adata.obs["patient"].map(sub_info["Subtype"])
# print("Number of cells without mol_subtype:", adata.obs["mol_subtype"].isna().sum())

major_ct = ["Lymphoid cell", "Epithelial cell", "Mast cell", "Endocrine cell",
            "Endothelial cell", "Fibroblast", "Macrophage", "Myeloid cell"]
minor_ct = ["CD4+ T cell", "CD8+ T cell", "DC", "Endocrine cell",
            "Endothelial cell", "Epithelial cell", "Macrophage M1",
            "Macrophage M2", "Mast cell", "Memory B cell", "Naive B cell", "NK cell",
            "Neutrophil", "Plasma cell", "Treg", "iCAF", "myCAF"]
ct = "Epithelial cell"

# ------------------------------------------------------------------------------
# Quality check
# ------------------------------------------------------------------------------
# adata_ct = adata[adata.obs["cell_type2"] == ct].copy()

# sc.pl.umap(
#     adata_ct,
#     color='nCount_RNA',
#     color_map='viridis',
#     title='UMAP colored by Raw Transcript Count',
#     show=True
# )

# # Filter cells with nCount_RNA >= 1000
# adata_ct_filtered = adata_ct[adata_ct.obs['nCount_RNA'] >= 1000, :].copy()
# sc.pl.umap(
#     adata_ct_filtered,
#     color='nCount_RNA',
#     color_map='viridis',
#     title='UMAP After Filtering (nCount_RNA ≥ 1000)',
#     show=True
# )

# ------------------------------------------------------------------------------
# Classify the single cell data using state loadings from bulk data
# ------------------------------------------------------------------------------
W = pd.read_csv("/net/beegfs/cfg/tgac/xlin/florenz_copy/GCBLADE/data/Lee/results/evaluate/results_consensus/with_expectation/state/cell_type2_StateLoadings_specK.csv", index_col = 0) # CD8 has 3 states
# W = pd.read_csv("/net/beegfs/cfg/tgac/xlin/florenz_copy/GCBLADE/data/Lee/results/evaluate/results_consensus/with_expectation/state/cell_type2_StateLoadings_specK2.csv", index_col = 0) # CD8 has 2 states


output_dir = "/net/beegfs/cfg/tgac/xlin/florenz_copy/GCBLADE/data/Lee/results/evaluate/results_consensus/with_expectation/state/simulation/classified"
os.makedirs(output_dir, exist_ok=True)

adata_ct = adata[adata.obs["cell_type2"] == ct].copy()
reprocess_adata_subset_scANVI(adata_ct,use_rep = 'X_pca')


# cols = [col for col in W.columns if col.startswith(f"{ct}_")]
# genes = [gene for gene in W.index if gene in adata_ct.raw.var_names]
# W_subset = W.loc[genes, cols]
# nclust = W_subset.shape[1]
# adata_ct = adata_ct.raw[:,genes].to_adata()
# data_for_cnmf = safe_zscore(np.transpose(adata_ct.X).toarray(), axis=0)
# # data_for_cnmf_df = pd.DataFrame(data_for_cnmf, index=adata_ct.var_names, columns=adata_ct.obs_names)

# # Save as CSV
# # data_for_cnmf_df.to_csv(os.path.join(output_dir, f"data_for_cnmf_{ct}.csv"))

# cNMF_model = cnmf.CNMF(data_for_cnmf, nclust, niter=10000)
# reprocess_adata_subset_scANVI(adata_ct,use_rep = 'X_pca')

# # Set W
# cNMF_model.W = W_subset
# # Recover state assignments (calculate H with W)
# cNMF_model.factorize(compute_w=False, niter=10)


# for i in range(nclust):
#     adata_ct.obs['H'+str(i+1)] = cNMF_model.H[i,:]

# Save H
# H_df = pd.DataFrame(cNMF_model.H)
# H_df.to_csv(os.path.join(output_dir,f"cNMF_H_{ct}.csv"), index=False)

# sc.pl.umap(adata_ct,color = ['H'+str(i+1) for i in range(nclust)], legend_loc = 'right margin', s = 40, show = False)
sc.pl.umap(adata_ct,color = ['patient'], s = 40, show = False) # legend_loc = 'best',

plt.savefig(os.path.join(output_dir, f"umap_{ct}_2.png"))
plt.close()

# # Assign states to cells
# cNMF_model_H = pd.read_csv("/net/beegfs/cfg/tgac/xlin/florenz_copy/GCBLADE/data/Lee/results/evaluate/results_consensus/with_expectation/state/simulation/classified/cNMF_H_CD8+ T cell_2.csv")
# cNMF_model_H = pd.read_csv("/net/beegfs/cfg/tgac/xlin/florenz_copy/GCBLADE/data/Lee/results/evaluate/results_consensus/with_expectation/state/simulation/classified/cNMF_H_Epithelial cell.csv")

# samples_assigned_states = (cNMF_model_H.values.argmax(axis=0) + 1).astype(int)
# samples_df = pd.DataFrame({"State": samples_assigned_states}, index=adata_ct.obs.index)

# # print(f"Number of cells in adata_ct: {adata_ct.n_obs}")
# # print(f"Number of cells in samples_df: {samples_df.shape[0]}")

# adata_ct.obs.index = adata_ct.obs.index.astype(str)
# samples_df.index = samples_df.index.astype(str)

# adata_ct.obs["State"] = samples_df["State"].astype("category")
# print(adata_ct.obs["State"].isna().sum())


# unique_states = np.unique(samples_assigned_states)

# for state in unique_states:
#     # Convert `state` to a string explicitly for mapping
#     state_str = str(state)

#     # Create a temporary column highlighting only the current state
#     adata_ct.obs["State_Highlight"] = adata_ct.obs["State"].apply(lambda x: state_str if str(x) == state_str else "R")

#     adata_ct.obs["State_Highlight"] = pd.Categorical(
#         adata_ct.obs["State_Highlight"], categories=[state_str, "R"], ordered=True
#     )
    
#     # Generate and save UMAP plot
#     sc.pl.umap(adata_ct, color="State_Highlight", palette=["blue","lightgray"], title=f"State {state}", show=False)

#     # Save the figure with corrected filename formatting
#     plt.savefig(os.path.join(output_dir, f"umap_{ct}_state_{state}.png"))
#     plt.close("all")

#     # Remove the temporary column after each plot
#     del adata_ct.obs["State_Highlight"]


# ------------------------------------------------------------------------------
# Color the single cell data by gene of interest
# ------------------------------------------------------------------------------

# # Plot cells based on a specific gene
# gene_of_interest = "UBE2C"

# # Extract expression data for the gene
# gene_idx = list(adata_ct.raw.var_names).index(gene_of_interest)
# gene_expression = adata_ct.raw.X[:, gene_idx].toarray().flatten()

# # without threshold on expression
# expressed_cells = gene_expression > 0
# # adata_ct.obs[f'{gene_of_interest}_expressed'] = np.where(expressed_cells, 'E', 'N')
# adata_ct.obs[f'{gene_of_interest}_expression'] = np.where(gene_expression > 0, gene_expression, np.nan)

# # Plot UMAP with gradient for expressing cells and light gray for non-expressing ones
# sc.pl.umap(
#     adata_ct,
#     color=[f'{gene_of_interest}_expression'],
#     color_map="viridis",
#     na_color="lightgray",
#     legend_loc='right margin',
#     show=False
# )

# plt.savefig(os.path.join(output_dir, f"umap_{ct}_{gene_of_interest}_raw.png"))
# plt.close()

# # Get patient IDs of cells expressing the gene
# patients_expressing = adata_ct.obs.loc[expressed_cells, ['patient', 'mol_subtype']]

# # Save to CSV
# patients_expressing.to_csv(
#     os.path.join(output_dir, f"{ct}_{gene_of_interest}_patients_raw_2.csv"),
#     index=True
# )


# # Set a threhsold on expression
# mean_expr = np.mean(gene_expression)
# std_expr = np.std(gene_expression)

# threshold = mean_expr + 2 * std_expr
# over_expressed_cells = gene_expression > threshold

# adata_ct.obs[f'{gene_of_interest}_overexpressed'] = np.where(over_expressed_cells, 'O', 'N')

# # Plot
# sc.pl.umap(
#     adata_ct,
#     color=[f'{gene_of_interest}_overexpressed'],
#     palette=["lightgray", "blue"],
#     legend_loc='right margin',
#     show=False
# )
# plt.savefig(os.path.join(output_dir, f"umap_{ct}_{gene_of_interest}.png"))
# plt.close()

# Get patient IDs of cells expressing the gene
# patients_overexpressing = adata_ct.obs.loc[over_expressed_cells, ['patient', 'mol_subtype']]

# Save to CSV
# patients_overexpressing.to_csv(
#     os.path.join(output_dir, f"{ct}_{gene_of_interest}_patients.csv"),
#     index=True
# )

