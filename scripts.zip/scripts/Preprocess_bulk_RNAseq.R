#!/usr/bin/env Rscript
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# Preprocess_bulk_RNAseq.R
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#
# Preprocess Bulk RNAseq data in the exact same way as the scRNAseq data was processed
# & format for use in BLADE
# Author: Mischa Steketee (m.f.b.steketee@amsterdamumc.nl)
#
# Usage:
# Rscript Preprocess_bulk_RNAseq.R -i<input_readcounts_file> --samples{input_samplesheet_file} -o{output_file}
# -output_plot{output_plot_file}
#
# TODO:
# 1) 
# History:
# 04-10-2022: Creation
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# 0.1  Import Libraries
#-------------------------------------------------------------------------------
library(optparse)
library(reticulate)
library(dplyr)
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# 1.0  Parse commandline arguments
#-------------------------------------------------------------------------------

option_list = list(
  make_option(c("-i", "--input"), action = "store", default = NA, type = 'character', help = "Provide path to input data file"),
  make_option(c("-o", "--output"), action = "store", default = NA, type = 'character', help = "Provide path to output file")
  )
input_file = (parse_args(OptionParser(option_list = option_list)))$input
output_file = (parse_args(OptionParser(option_list = option_list)))$output

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# 1.1  Load data
#-------------------------------------------------------------------------------
## Load raw bulk readcounts
raw_counts = read.table(input_file, sep = '\t', header = T)
## Change row names to a new column containing the ensemble_IDs
raw_counts$ensemble_ID <- rownames(raw_counts)
raw_counts$ensemble_ID <- substring(raw_counts$ensemble_ID, 1, 15)

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# 2.0 Normalize by library size
#-------------------------------------------------------------------------------

manual_normalized_counts = raw_counts %>%
  mutate_at(vars(-c(gene_names, ensemble_ID)), funs(./sum(.)*10000)) 

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# 3.0 Format data
#-------------------------------------------------------------------------------
## Make list of lists so you have big list with list per patient with exp data
bulk <- sapply(manual_normalized_counts[,c(-1,-ncol(raw_counts))], list)
genelist = raw_counts$gene_names
bulkdata = list(bulk, genelist)
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# 4.0 Write data to output dir
#-------------------------------------------------------------------------------
py_save_object(bulkdata, output_file, pickle = "pickle")
