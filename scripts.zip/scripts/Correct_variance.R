#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# Correct_variance.R
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#
# Correct variance by fitting LOESS to  mean-variance trend
#
# Author: Jurriaan Janssen (j.janssen4@amsterdamumc.nl)
#
# TODO:
# 1) 
#
# History:
#  15-09-2022: File creation, write code
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# 0.1  Import Libraries
#-------------------------------------------------------------------------------
suppressWarnings(library(reticulate))
suppressWarnings(library(scran))
library(optparse)
use_condaenv('snakemake')
builtins <- import_builtins()
pickle <- import('pickle')
source_python('scripts/utils.py')
#-------------------------------------------------------------------------------
# 1.1 Parse snakemake objects
#-------------------------------------------------------------------------------
option_list = list(
    make_option(c("-i","--input"), action = "store", default = NA, type = "character", help = "Provide path to signature matrix"),
    make_option(c("-o","--output"), action = "store", default = NA, type = "character", help = "Provide path to corrected signature matrix")
)

input = (parse_args(OptionParser(option_list = option_list)))$input
output = (parse_args(OptionParser(option_list = option_list)))$output    

#-------------------------------------------------------------------------------
# 2.1 Read Signature
#-------------------------------------------------------------------------------
# read Signature
print("reading signature")
Signature <- read_Signature(input)

#-------------------------------------------------------------------------------
# 2.3 extract mean,variance and std
#-------------------------------------------------------------------------------
# extract matrices
variance <- Signature[[1]]
mean <- Signature[[2]]
std <- Signature[[3]]
ct_list <- Signature[[4]]
gene_list <- Signature[[5]]
#-------------------------------------------------------------------------------
# 2.3 Fit mean-variance trend to obtain new std's
#-------------------------------------------------------------------------------
New_std <- matrix(nrow=length(gene_list),ncol=length(ct_list))
for(i in seq(length(ct_list))){
    trend <- fitTrendVar(mean[,i],variance[,i])$trend
    New_std[,i] <- trend(mean[,i])
}


New_std2 <- matrix(nrow=length(gene_list),ncol=length(ct_list))
for(i in seq(length(ct_list))){
    trend <- fitTrendVar(mean[,i],std[,i])$trend
    New_std2[,i] <- trend(mean[,i])
}

# rename signature genes
#setwd("/net/beegfs/cfg/tgac/f.otterloo/GCBLADE/data/Lee/raw_counts/single_cell/")
#file <- list.files()[1]
#sc_data <- read.csv(file)
#colnames(sc_data)[1] <- "Symbol"

#Signature[[6]]$Genelist <- sc_data$Symbol

#-------------------------------------------------------------------------------
# 3.1 write to file
#-------------------------------------------------------------------------------
write_Signature(Signature[[6]], New_std, output)


