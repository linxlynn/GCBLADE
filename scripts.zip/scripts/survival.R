library(dplyr)
library(tidyr)
library(readr)
library(ggplot2)
library(viridis)
library(pheatmap)
library(readxl)
library(survival)
library(survminer)
library(gridExtra)
library(patchwork)
library(cowplot)

grid.draw.ggsurvplot <- function(x){
  survminer:::print.ggsurvplot(x, newpage = FALSE)
}

#-------------------------------------------------------------------------------
# 1.0 load data
#-------------------------------------------------------------------------------
# load DSS and OS data
MSI_supp <- read.csv("/net/beegfs/cfg/tgac/xlin/florenz_copy/data/TCGA_STAD/edited_data/Clinical_files/MSI_M0_supplementary.csv")
MSS_supp <- read.csv("/net/beegfs/cfg/tgac/xlin/florenz_copy/data/TCGA_STAD/edited_data/Clinical_files/MSS_M0_supplementary.csv")

# Ensure consistent formatting of patient barcodes
MSI_supp$bcr_patient_barcode <- gsub("-", ".", MSI_supp$bcr_patient_barcode)
MSS_supp$bcr_patient_barcode <- gsub("-", ".", MSS_supp$bcr_patient_barcode)

# load state data
samples <- read.csv("/net/beegfs/cfg/tgac/xlin/florenz_copy/GCBLADE/data/Lee/results/evaluate/results_consensus/with_expectation/state/cell_type2_samples_assigned_states_specK.csv")
samples <- samples[samples$CellType == "Epithelial cell", ]

colors <- c("#E69F00", "#56B4E9", "#009E73")

#-------------------------------------------------------------------------------
# 2.0 make kaplan meier curves
#-------------------------------------------------------------------------------
combined_df <- rbind(MSS_supp, MSI_supp)

# Merge with sample data on patient barcode
combined_df <- merge(combined_df, samples, by.x = "bcr_patient_barcode", by.y = "Sample")

# Convert time variables from days to years
combined_df$DSS.time <- combined_df$DSS.time / 365
combined_df$OS.time <- combined_df$OS.time / 365

# Ensure event columns are numeric (1 = event, 0 = censored)
combined_df$DSS <- as.numeric(combined_df$DSS)
combined_df$OS <- as.numeric(combined_df$OS)

# Create strata based on sample states
combined_df$combined_strata <- as.factor(combined_df$State)

# make DSS survival object
surv_object_DSS <- Surv(time = combined_df$DSS.time, event = combined_df$DSS)
fit_DSS <- survfit(surv_object_DSS ~ combined_strata, data = combined_df)

# make OS survival object
surv_object_OS <- Surv(time = combined_df$OS.time, event = combined_df$OS)
fit_OS <- survfit(surv_object_OS ~ combined_strata, data = combined_df)

# Generate DSS Kaplan-Meier plot
plot_DSS <- ggsurvplot(
  fit_DSS, 
  data = combined_df, 
  pval = TRUE, 
  risk.table = TRUE,
  title = "Kaplan-Meier Curve - Disease-Specific Survival",
  legend.title = "State",
  legend.labs = levels(combined_df$combined_strata),
  xlab = "Years",
  ylab = "Survival Probability",
  palette = colors
)

# Generate OS Kaplan-Meier plot
plot_OS <- ggsurvplot(
  fit_OS, 
  data = combined_df, 
  pval = TRUE, 
  risk.table = TRUE,
  title = "Kaplan-Meier Curve - Overall Survival",
  legend.title = "State",
  legend.labs = levels(combined_df$combined_strata),
  xlab = "Years",
  ylab = "Survival Probability",
  palette = colors
)

# Arrange plots side by side
grid.arrange(plot_DSS$plot, plot_OS$plot, ncol = 2)

ggsave("/net/beegfs/cfg/tgac/xlin/florenz_copy/GCBLADE/data/Lee/results/evaluate/results_consensus/with_expectation/state/epithelial_OS.png", plot_OS, width = 6, height = 8)
ggsave("/net/beegfs/cfg/tgac/xlin/florenz_copy/GCBLADE/data/Lee/results/evaluate/results_consensus/with_expectation/state/epithelial_DSS.png", plot_DSS, width = 6, height = 8)

#-------------------------------------------------------------------------------
# 3.0 plot cell fractions based on epithelial states
#-------------------------------------------------------------------------------
# load cell fractions
cf_file = read.csv("/net/beegfs/cfg/tgac/xlin/florenz_copy/GCBLADE/data/Lee/results/evaluate/results_consensus/with_expectation/cell_type2_STAD_ALL.hierarchical_estimated_cf.k6.csv")

minor_celltypes <- c("CD4..T.cell", "CD8..T.cell", "DC", "Endocrine.cell",
                     "Endothelial.cell", "Epithelial.cell", "Macrophage.M1",
                     "Macrophage.M2", "Mast.cell", "Memory.B.cell", "Naive.B.cell", "NK.cell",
                     "Neutrophil", "Plasma.cell", "Treg", "iCAF", "myCAF")

norm_celltypes <- setdiff(minor_celltypes, "Epithelial.cell")

merged_df <- merge(cf_file, samples, by.x = "barcode", by.y = "Sample")
merged_df$State <- as.factor(merged_df$State)

# Without normalization
merged_df <- merged_df %>% select(all_of(minor_celltypes), State)

## # Normalization
## merged_df <- merged_df %>%
##     select(all_of(norm_celltypes), State)

merged_df <- merged_df %>%
    mutate(Norm = rowSums(select(., all_of(norm_celltypes)))) %>%  # Sum of all cell types except Epithelial
    mutate(across(all_of(norm_celltypes), ~ . / Norm)) %>%  # Normalize
    select(-Norm)

# Mutate to proper format
long_df <- merged_df  %>% pivot_longer(cols = -State, names_to = "CellType", values_to = "Fraction")

# Plot cell fractions grouped by State
plot <- ggplot(long_df, aes(x = CellType, y = Fraction, fill = State)) +
    geom_boxplot() +
    theme_minimal() +
    scale_fill_manual(values = colors) +
    labs(title = "Cell Fractions by State",
         x = "Cell Type",
         y = "Fraction") +
    theme(axis.text.x = element_text(angle = 45, hjust = 1))

ggsave("/net/beegfs/cfg/tgac/xlin/florenz_copy/GCBLADE/data/Lee/results/evaluate/results_consensus/with_expectation/state/cell_frac_epithelial_state_norm.png", plot, width = 10, height = 6)


# -----------------------------------------------------------------------------
# 4.0 check histological subtype in each state
# -----------------------------------------------------------------------------
patient_data <- read.delim("/net/beegfs/cfg/tgac/xlin/florenz_copy/GCBLADE/data/TCGA_STAD/nationwidechildrens.org_clinical_patient_stad.txt", header = TRUE)

patient_data$bcr_patient_barcode <- gsub("-", ".", patient_data$bcr_patient_barcode)

# simplify the histological subtypes
patient_data <- patient_data %>%
  mutate(hist_subtype = case_when(
    grepl("Stomach, Adenocarcinoma, Not Otherwise Specified \\(NOS\\)", histologic_diagnosis) ~ "NOS",
    grepl("Stomach, Adenocarcinoma, Diffuse Type", histologic_diagnosis) ~ "diffuse",
    grepl("Stomach, Intestinal Adenocarcinoma", histologic_diagnosis) ~ "intestinal",
    TRUE ~ "NOS"
    ))

# Merge with merged_df based on 'bcr_patient_barcode'
merged_df <- merged_df %>%
  left_join(patient_data %>% select(bcr_patient_barcode, hist_subtype), 
            by = c("barcode" = "bcr_patient_barcode"))
merged_df <- merged_df %>% filter(hist_subtype != "NOS")

# Plot hist_subtype counts per state
plot2 <- ggplot(merged_df, aes(x = State, fill = hist_subtype)) +
    geom_bar(position = "stack") +
    scale_fill_manual(values = colors) +
  labs(title = "Distribution of Histological Subtypes by State",
       x = "State",
       y = "Count",
       fill = "Histological Subtype") +
    theme_minimal()


## merged_df_percentage <- merged_df %>%
##   group_by(State, hist_subtype) %>%
##   summarise(count = n(), .groups = "drop") %>%
##   mutate(percentage = count / sum(count))  # Convert to percentage

## # Plot the stacked bar chart with percentages
## plot2 <- ggplot(merged_df_percentage, aes(x = State, y = percentage, fill = hist_subtype)) +
##   geom_bar(stat = "identity", position = "fill") +  # "fill" ensures bars are stacked to 100%
##     scale_y_continuous(labels = scales::percent_format()) +  # Format y-axis as percentages
##     scale_fill_manual(values = colors) +
##   labs(title = "Proportion of Histological Subtypes by State",
##        x = "State",
##        y = "Percentage",
##        fill = "Histological Subtype") +
##   theme_minimal() +
##   theme(axis.text.x = element_text(angle = 45, hjust = 1))

ggsave("/net/beegfs/cfg/tgac/xlin/florenz_copy/GCBLADE/data/Lee/results/evaluate/results_consensus/with_expectation/state/histology_epithelial_count_noNOS.png", plot2, width = 10, height = 6)

# -----------------------------------------------------------------------------
# 5.0 enrichment in each state using chi squared test
# -----------------------------------------------------------------------------
# histological subtype
no_NOS <- merged_df %>% filter(hist_subtype != "NOS")

count_by_state <- no_NOS %>%
    group_by(State, hist_subtype) %>%
    summarise(count = n(), .groups = "drop")

for (s in c(1, 2, 3)) {
    cat(paste("\nState", s, ":\n"))
    print(count_by_state %>% filter(State == s))
}

# Define the contingency tables for each state
state_1 <- matrix(c(60, 103, 17, 41), nrow = 2, byrow = TRUE)
state_2 <- matrix(c(27, 119, 8, 50), nrow = 2, byrow = TRUE)
state_3 <- matrix(c(76, 70, 33, 25), nrow = 2, byrow = TRUE)

# Function to compute Chi-squared and Fisher’s Exact tests
chi_test <- function(table, state_name) {
    chi2_test <- chisq.test(table)
  
    return(data.frame(
        State = state_name,
        `Chi-squared p-value` = chi2_test$p.value
    ))
}

# Run the tests for each state
results <- bind_rows(
  chi_test(state_1, "State 1"),
  chi_test(state_2, "State 2"),
  chi_test(state_3, "State 3")
)

# Print the results
print(results)

# molecular subtype
GEX_df <- read.csv("/net/beegfs/cfg/tgac/xlin/florenz_copy/GCBLADE/data/Lee/results/evaluate/results_consensus/with_expectation/purification/cell_type2_Epithelial.cell_purification.csv", row.names = 1)
assigned_states <- read.csv("/net/beegfs/cfg/tgac/xlin/florenz_copy/GCBLADE/data/Lee/results/evaluate/results_consensus/with_expectation/state/cell_type2_samples_assigned_states_specK.csv")

cell_type <- unique(GEX_df$CellType)
cell_type <- cell_type %>%
    gsub("\\.\\.", "+ ", .) %>%
    gsub("\\.", " ", .)

# Filter state info for the current cell type
state_info <- assigned_states %>% filter(CellType == cell_type)

# Merge state info into GEX_df based on sample row names
GEX_df$Sample <- rownames(GEX_df)
GEX_df <- GEX_df %>% left_join(state_info, by = "Sample")

count_by_state2 <- GEX_df %>%
    group_by(State, Subtype) %>%
    summarise(count = n(), .groups = "drop")

for (s in c(1, 2, 3)) {
    cat(paste("\nState", s, ":\n"))
    print(count_by_state2 %>% filter(State == s))
}

# Define the contingency tables for each state
state_1 <- matrix(c(60, 134, 9, 17, 12, 32, 19, 53), nrow = 4, byrow = TRUE)
state_2 <- matrix(c(27, 167, 0, 26, 10, 34, 12, 60), nrow = 4, byrow = TRUE)
state_3 <- matrix(c(107, 87, 17, 9, 22, 22, 41, 31), nrow = 4, byrow = TRUE)

# Run the tests for each state
results2 <- bind_rows(
  chi_test(state_1, "State 1"),
  chi_test(state_2, "State 2"),
  chi_test(state_3, "State 3")
)

# Print the results
print(results2)

# -----------------------------------------------------------------------------
# 6.0 correlation between states of different cell types
# -----------------------------------------------------------------------------

scores <- read.csv("/net/beegfs/cfg/tgac/xlin/florenz_copy/GCBLADE/data/Lee/results/evaluate/results_consensus/with_expectation/state/cell_type2_StateScores_specK.csv", row.names = 1)

scores <- as.data.frame(sapply(scores, as.numeric, USE.NAMES = TRUE), row.names = rownames(scores))
# scaled_scores <- scale(t(scores))

minmax_scale <- function(x) {
  return((x - min(x, na.rm = TRUE)) / (max(x, na.rm = TRUE) - min(x, na.rm = TRUE)))
}

scaled_scores <- t(apply(t(scores), 1, minmax_scale))

# correlation_matrix <- cor(t(scores), use = "pairwise.complete.obs", method = "pearson")
correlation_matrix <- cor(scaled_scores, use = "pairwise.complete.obs", method = "pearson")

par(mar = c(10, 10, 4, 4)) # Increase bottom and left margins to fit labels
plot <- pheatmap(correlation_matrix, 
         color = viridis(length(unique(c(correlation_matrix)))),  # Automatically set color scale
         cluster_rows = FALSE,  # Disable row clustering (dendrogram)
         cluster_cols = FALSE,  # Disable column clustering (dendrogram)
         show_rownames = TRUE, 
         show_colnames = TRUE,
         legend = TRUE)
print(plot)
