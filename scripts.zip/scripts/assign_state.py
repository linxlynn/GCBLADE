# assign_state.py
#
# Assign the state to samples and genes
#
#

import pandas as pd
import argparse
import numpy as np
import re

# Parse arguments
parser = argparse.ArgumentParser(description="Assign states based on loadings and scores.")
parser.add_argument("--loadings", required=True, help="Path to loadings file (genes x states)")
parser.add_argument("--scores", required=True, help="Path to scores file (states x samples)")
parser.add_argument("--output1", required=True, help="Path to genes assigned states")
parser.add_argument("--output2", required=True, help="Path to samples assigned states")
args = parser.parse_args()

# Load files
loadings = pd.read_csv(args.loadings, index_col=0)
scores = pd.read_csv(args.scores, index_col=0)

print(loadings.head())
print(scores.head())

# Convert all data to numeric
loadings = loadings.apply(pd.to_numeric, errors='coerce')
scores = scores.apply(pd.to_numeric, errors='coerce')

# Extract unique cell types
cell_types = set(col.split('_', 1)[0] for col in loadings.columns)
print("Extracted cell types:", cell_types)

# Initialize empty DataFrames
genes_assigned_states_df = pd.DataFrame(columns=["Gene", "CellType", "State"])
samples_assigned_states_df = pd.DataFrame(columns=["Sample", "CellType", "State"])

for cell_type in cell_types:
    # Extract columns and rows for the current cell type
    loadings_subset = loadings.filter(regex=f"^{re.escape(cell_type)}_", axis=1)
    scores_subset = scores.filter(regex=f"^{re.escape(cell_type)}_", axis=0)

    # Assign states to genes
    genes_assigned_states = loadings_subset.values.argmax(axis=1)
    genes_df = pd.DataFrame({
        "Gene": loadings.index,
        "CellType": cell_type,
        "State": genes_assigned_states + 1
    })
    genes_assigned_states_df = pd.concat([genes_assigned_states_df, genes_df], ignore_index=True)

    # Assign states to samples
    samples_assigned_states = scores_subset.values.argmax(axis=0)
    samples_df = pd.DataFrame({
        "Sample": scores.columns,
        "CellType": cell_type,
        "State": samples_assigned_states + 1
    })
    samples_assigned_states_df = pd.concat([samples_assigned_states_df, samples_df], ignore_index=True)
    
# Save results to CSV files
genes_assigned_states_df.to_csv(args.output1, index=False)
samples_assigned_states_df.to_csv(args.output2, index=False)
