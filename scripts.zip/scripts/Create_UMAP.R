#!/usr/bin/env Rscript
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# Create_UMAP.R
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#
# Create UMAP with phenotyped single cell data
#
#
# Usage:
# Rscript Create_UMAP.R --input_file <path> --cell_level <cell_type/cell_type2> --output_plot <path>
# 
# History:
# 28-10-2024: Adapted from Florenz's Figure_4.R 
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# 0.1  Import Libraries
#--------------------------------------------------------------------------------

suppressMessages({
library(dplyr)
library(ggplot2)
library(ggrepel)
library(Seurat)
library(optparse)
})


option_list = list(
    make_option(c("--input_file"), action = "store", default = NA, type = 'character', help = "Provide path to file containing Seurat object"),
    make_option(c("--cell_level"), action = "store", default = NA, type = 'character', help = "Specify major/minor cell type"),
    make_option(c("--output_plot"), action = "store", default = NA, type = 'character', help = "Provide path to file of UMAP major/minor cell type plot")
)

# Parse arguments once
args <- parse_args(OptionParser(option_list = option_list))

input_file <- args$input_file
cell_level <- args$cell_level
output_plot <- args$output_plot


#-------------------------------------------------------------------------------
# 1.0 load data
#-------------------------------------------------------------------------------

load(file = input_file)

#--------------------------------------------------------------------------------
# 2.0 Plot UMAP
#--------------------------------------------------------------------------------

if (cell_level == "cell_type"){
    cell_type <- data.frame(cell_type = GC_seuratObj$cell_type)
    cell_type_umap <- data.frame(GC_seuratObj@reductions$umap@cell.embeddings[, c(1, 2)])
    colnames(cell_type_umap) <- c("umap_1", "umap_2")
    cell_type_merged <- cbind(cell_type, cell_type_umap)

    cell_type_plot <- ggplot(cell_type_merged, aes(x = umap_1, y = umap_2, color = GC_seuratObj$cell_type)) +
        geom_point(size=0.5) +
        labs(title = "UMAP of major cell types",
             x = "UMAP 1",
             y = "UMAP 2",
             color = "Major cell types") +
        guides(color = guide_legend(override.aes = list(size = 2))) + 
        theme_minimal() +
        theme(
            plot.title = element_text(hjust = 0.5, face = "bold", size = 8),
            panel.grid.major = element_blank(),
            panel.grid.minor = element_blank(),
            axis.line = element_line(color = 'black'),
            axis.ticks = element_line(color = 'black'),
            axis.ticks.length = unit(0.2, "cm"),
            axis.title = element_text(face = "bold", size = 7),
            legend.position = "top",
            legend.justification = "left",
            legend.key.size = unit(0.1, "cm"),
            legend.title = element_blank(),
            legend.text = element_text(size = 3)
        )

    ggsave(output_plot, cell_type_plot, width = 8.5, height = 9.3, units = "cm")
} else {
    cell_type2 <- data.frame(cell_type = GC_seuratObj$cell_type2)
    cell_type2_umap <- data.frame(GC_seuratObj@reductions$umap@cell.embeddings[, c(1, 2)])
    colnames(cell_type2_umap) <- c("umap_1", "umap_2")
    cell_type2_merged <- cbind(cell_type2, cell_type2_umap)

    cell_type2_plot <- ggplot(cell_type2_merged, aes(x = umap_1, y = umap_2, color = GC_seuratObj$cell_type2)) +
        geom_point(size=0.5) +
        labs(title = "UMAP of minor cell types",
             x = "UMAP 1",
             y = "UMAP 2",
             color = "Minor cell types") +
        guides(color = guide_legend(override.aes = list(size = 2))) + 
        theme_minimal() +
        theme(
            plot.title = element_text(hjust = 0.5, face = "bold", size = 8),
            panel.grid.major = element_blank(),
            panel.grid.minor = element_blank(),
            axis.line = element_line(color = 'black'),
            axis.ticks = element_line(color = 'black'),
            axis.ticks.length = unit(0.2, "cm"),
            axis.title = element_text(face = "bold", size = 7),
            legend.position = "top",
            legend.justification = "left",
            legend.key.size = unit(0.1, "cm"),
            legend.title = element_blank(),
            legend.text = element_text(size = 5)
        )

    ggsave(output_plot, cell_type2_plot, width = 8.5, height = 9.3, units = "cm")
}

