# Adapted from Jurriaan's Heatmap_Loadings.R

suppressMessages({
    library(dplyr)
    library(ComplexHeatmap)
    library(optparse)
    library(scales)
})

# Parse command-line arguments
option_list <- list(
    make_option("--input", type = "character", help = "Loadings file"),
    make_option("--output", type = "character", help = "Heatmap"),
    make_option("--cell_level", type = "character", help = "Specify cell_type or cell_type2")
)

args <- parse_args(OptionParser(option_list = option_list))

# Read StateLoadings (genes x <cell_type>_<state_number>)
W_matrix <- read.csv(args$input, row.names = 1, check.names = FALSE)


# Define cell type colors
if (args$cell_level == "cell_type") {
    Celltype_colors <- data.frame(
        celltype = c("Lymphoid cell", "Epithelial cell", "Mast cell", "Endocrine cell",
                     "Endothelial cell", "Fibroblast", "Macrophage", "Myeloid cell"),
        celltype_color = character(length = 8)
    )
} else {
    Celltype_colors <- data.frame(
        celltype = c("CD4+ T cell", "CD8+ T cell", "DC", "Endocrine cell", "Epithelial cell",
                 "Endothelial cell", "Macrophage M1", "Macrophage M2",
                 "Mast cell", "Memory B cell", "Naive B cell", "NK cell",
                 "Neutrophil", "Plasma cell", "Treg", "iCAF", "myCAF"),
        celltype_color = character(length = 17)
    )
}


# Generate colors
tol_colors <- c("#E69F00", "#56B4E9", "#009E73", "#F0E442",
                "#0072B2", "#D55E00", "#CC79A7", "#999999",
                "#CC6677", "#332288", "#DDCC77", "#117733",
                "#88CCEE", "#882255", "#44AA99", "#999933", "#AA4499")


# Assign colors to cell types
colors <- setNames(tol_colors[seq_len(nrow(Celltype_colors))], Celltype_colors$celltype)

# Apply colors to Celltype_colors dataframe
Celltype_colors$celltype_color <- colors[Celltype_colors$celltype]

# Extract cell type and state information from column names
States <- data.frame(States = colnames(W_matrix)) %>%
    mutate(celltype = gsub("(_\\d+)$", "", States),
           state_number = gsub(".*_", "", States),
           state_number = as.integer(state_number)) %>%
    left_join(Celltype_colors, by = c("celltype" = "celltype"))

# Create Color palette for States
state_colors <- c()
for (celltype in unique(States$celltype)) {
    states <- States %>% filter(celltype == !!celltype)
    nstates <- nrow(states)
    if (nstates == 1) {
        colors <- states$celltype_color
        
    } else {
        colors <- colorRampPalette(c('white',unique(states$celltype_color),'black'))((nstates+2)*100)[seq(200,100*(nstates+1), by = 100)]
    }
    names(colors) <- states$States
    state_colors <- c(state_colors, colors) 
}

# Add state colors to the States data frame
States <- States %>%
  mutate(StateColors = state_colors[States])

# Define color palette for cell types
celltype_color_pal <- setNames(States$celltype_color, States$celltype)

# Create the top annotation
top_annotation <-
    HeatmapAnnotation(
    Celltype =States$celltype,
    State =  States$States,
    col = list(
        Celltype = celltype_color_pal,
        State = state_colors),
    annotation_name_gp= gpar(fontsize = 0),

    show_legend = c(FALSE,FALSE))


    
nTopGenes <- 1
GeneSelection <- c()
# Select top n genes per state
for(state in States$States){
    Genes_to_add <- W_matrix %>% arrange(desc(.[[state]])) %>% head(nTopGenes) %>% rownames()
    GeneSelection <- c(GeneSelection,Genes_to_add)
}

# Fetch gene annotations
Text_anno <- data.frame(Gene = GeneSelection,States = rep(States$States,each=nTopGenes)) %>%
    left_join(States)


right_annotation <-
    rowAnnotation(
    Celltype =rep(States$celltype,each = nTopGenes),
    State =  rep(States$States, each = nTopGenes),
    Gene = anno_mark(at = seq(length(GeneSelection)), 
                     labels = Text_anno$Gene,
                     padding = 0.05,
                     labels_gp = gpar(col = state_colors[States$States], fontsize = 9)),
    col = list(
        Celltype = celltype_color_pal,
        State = state_colors),
    annotation_name_gp= gpar(fontsize = 0),
    show_legend = c(TRUE,FALSE))
        
pdf(args$output, height = 10, width = 10)
ht <- Heatmap(scale(W_matrix[GeneSelection,States$States]),
              name = 'Z-score',
              top_annotation = top_annotation ,
              right_annotation = right_annotation,
        cluster_columns =FALSE,
        column_title_gp = gpar(fontsize = 6,rot=45),
        show_column_names = F, show_row_names = F,
        cluster_rows = FALSE,
        heatmap_legend_param = list(direction = "horizontal",title_position = "topcenter",label_gp= gpar(fontsize = 6)))
draw(ht, heatmap_legend_side = "right",padding = unit(c(10, 10, 10, 10), "mm"))
dev.off()
