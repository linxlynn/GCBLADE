#!/usr/bin/env python3

"""
A minimal example script to run StateDiscovery (cNMF) for ALL cell types 
using default parameters. It saves W as "StateLoadings" and H as "StateScores."

1) Fractions.csv: (samples x cell_types)
2) Purified.pkl : {cell_type: DataFrame (samples x genes)}
3) Omega        : {cell_type: DataFrame (genes x cell_types)}
"""
import sys
import pandas as pd
import pickle
import argparse
import matplotlib.pyplot as plt
import matplotlib.cm as cm
import numpy as np

from StateDiscovery.cNMF import StateDiscovery_FrameWork
import StateDiscovery.cNMF
from StateDiscovery.lib import pymf

script_dir = "/net/beegfs/cfg/tgac/xlin/florenz_copy/GCBLADE/scripts/OncoBLADE/"
sys.path.insert(0, script_dir)
import Deconvolution.OncoBLADE


def main():
    # Parse command line arguments
    parser = argparse.ArgumentParser(description="Run StateDiscovery (cNMF) for all cell types.")
    parser.add_argument("--cf_file", required=True, help="CSV file of cell fractions (samples x cell_types)")
    parser.add_argument("--purified_file", required=True, help="Pickled file containing purified data (dict: {cell_type: DataFrame (samples x genes)})")
    parser.add_argument("--loadings", required=True, help="Output CSV file for StateLoadings")
    parser.add_argument("--scores", required=True, help="Output CSV file for StateScores")
    parser.add_argument("--plot", required=True, help="Output file for the cophenetic correlation plot")
    args = parser.parse_args()

    # Load Fractions table
    print(f"[INFO] Reading Fractions from {args.cf_file}")
    Fractions = pd.read_csv(args.cf_file, index_col=0)

    # Load Purified dictionary
    print(f"[INFO] Reading Purified GEX from {args.purified_file}")
    with open(args.purified_file, "rb") as f:
        Purified = pickle.load(f)

    final_obj = Purified['final_obj']
    samples = Purified['samples']
    genes_valid = Purified['genes_valid']
    celltypes = Purified['celltype_list']
    num_celltypes = len(celltypes)
    

    # ---- Default cNMF parameters ----
    # K               = None       # Automatically determine K (None)
    # K_major         = {"Endocrine cell": 2,
    # "Endothelial cell": 4,
    # "Epithelial cell": 4,
    # "Fibroblast": 3,
    # "Lymphoid cell": 3,
    # "Macrophage": 2,
    # "Mast cell": 2,
    # "Myeloid cell": 4}
    K_minor = {"CD4+ T cell": 3,
    "CD8+ T cell": 2,
    "DC": 3,
    "Endocrine cell": 2,
    "Endothelial cell": 2,
    "Epithelial cell": 3,
    "iCAF": 3,
    "Macrophage M1": 3,
    "Macrophage M2": 3,
    "Mast cell": 2,
    "Memory B cell": 3,
    "myCAF": 3,
    "Naive B cell": 3,
    "Neutrophil": 4,
    "NK cell": 3,
    "Plasma cell": 3,
    "Treg": 3}
    n_iter          = 10         # Initial cNMF runs
    n_final_iter    = 100        # Final cNMF runs
    min_cophenetic  = 0.9        # Threshold for cophenetic coefficient
    max_clusters    = 10         # Max number of clusters to test
    Ncores          = 4          # Number of parallel cores
    weighing        = "Omega"    # Weighing strategy

    # Dataframe to hold results for all cell types
    all_loadings = pd.DataFrame()
    all_scores = pd.DataFrame()
    all_cophcors = pd.DataFrame()

    paul_tol_colors = [
    "#4477AA", "#EE6677", "#228833", "#CCBB44", "#66CCEE",
    "#AA3377", "#BBBBBB", "#000000", "#E69F00", "#56B4E9",
    "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7",
    "#999999", "#882255"
    ]

    # Function to assign a color based on index
    def get_tol_color(idx):
        return paul_tol_colors[idx % len(paul_tol_colors)]
    
    # Run StateDiscovery for each cell type
    for ct in celltypes:
        print(f"\n[INFO] Running StateDiscovery for cell type: {ct}")

        ct_index = celltypes.index(ct)

        # specify K for each ct
        # K = K_major.get(ct)
        K = K_minor.get(ct)

        # Purified expression (samples x genes)
        GEX_df = pd.DataFrame(final_obj.Nu[:, :, ct_index], index=samples, columns=genes_valid)

        # Omega (genes x cell_types)
        Omega_df = pd.DataFrame(final_obj.Omega[:,ct_index],index=genes_valid,columns=[ct]) 

        # Run cNMF
        model = StateDiscovery_FrameWork(
            GEX       = GEX_df,
            Omega     = Omega_df,
            Fractions = Fractions,
            celltype  = ct,
            weighing  = weighing,
            K         = K,
            n_iter    = n_iter,
            n_final_iter = n_final_iter,
            min_cophenetic = min_cophenetic,
            max_clusters   = max_clusters,
            Ncores    = Ncores
        )

        # all_cophcors[ct] = cophcors
        
        # Rename cNMF outputs:
        # model.W -> StateLoadings, model.H -> StateScores
        # model.H has shape (#clusters x #samples)
        # model.W has shape (#genes x #clusters)
        StateScores_df   = pd.DataFrame(model.H, columns=GEX_df.index)
        StateLoadings_df = pd.DataFrame(model.W, index=GEX_df.columns)

        # Rename cols and rows in format <ct>_<state number>
        num_states = StateScores_df.shape[0]
        state_names = [f"{ct}_{state + 1}" for state in range(num_states)]
        StateScores_df.index = state_names
        StateLoadings_df.columns = state_names
        
        # Append to consolidated DataFrames
        all_loadings = pd.concat([all_loadings, StateLoadings_df], axis=1)
        all_scores = pd.concat([all_scores, StateScores_df], axis=0)

    # Plot cophenetic correlations
    plt.figure(figsize=(8,6))

    # for idx, (ct, cophcors) in enumerate(all_cophcors.items()):
    #     ks = range(2, max_clusters)  # The tested values of K
    #     color = get_tol_color(idx)
    #     plt.plot(ks, cophcors, marker='o', label=ct, color = color)


    # plt.xlabel("Number of Clusters (K)")
    # plt.ylabel("Cophenetic Correlation")
    # plt.title("Cophenetic Correlation vs. K for Each Cell Type")
    # plt.legend(loc='center left', bbox_to_anchor=(1, 0.5))
    # plt.grid(True)
    # plt.show()

    # Save plot
    print(f"[INFO] Cophenetic correlation plot saved to {args.plot}")
    plt.savefig(args.plot, dpi=300, bbox_inches="tight")
    
    # Save the results to specified output files
    print(f"[INFO] Saving StateLoadings to {args.loadings}")
    all_loadings.to_csv(args.loadings)

    print(f"[INFO] Saving StateScores to {args.scores}")
    all_scores.to_csv(args.scores)
        

    print("\n[INFO] StateDiscovery completed for all cell types.")
    # Optionally, do something with `results` in memory here.

if __name__ == "__main__":
    main()
