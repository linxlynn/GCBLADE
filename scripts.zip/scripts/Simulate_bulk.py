#!/usr/bin/python3
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# Simulate_bulk.py
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#
# Create simulated bulk transcriptome data from scRNAseq
#
# Author: Jurriaan Janssen (j.janssen4@amsterdamumc.nl)
#
# Usage:
"""
python3 scripts/Simulate_bulk.py \
-i {input.adata_classified} \
-o {output.simulated_bulk} \
-cache_dir {params.cache_dir}
"""
# TODO:
# 1)
#
# History:
#  29-11-2021: File creation, write code
#  03-12-2021: Remove log transformation and normalization
#  01-08-2022: Edits for CV
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# 0.1  Import Libraries
#-------------------------------------------------------------------------------
import argparse
import scanpy as sc
import pickle
import numpy as np
#-------------------------------------------------------------------------------
# 1.1 Parse command line arguments
#-------------------------------------------------------------------------------
def parse_args():
    "Parse inputs from commandline and returns them as a Namespace object."
    parser = argparse.ArgumentParser(prog = 'python3 Simulate_bulk.py',
        formatter_class = argparse.RawTextHelpFormatter, description =
        ' Create simulated bulk data from scRNAseq data  ')
    parser.add_argument('-i', help='path to adata_final',
                        dest='input',
                        type=str)
    parser.add_argument('-d', help='Directory containing 10X counts produced by "Prepare_scRNAseq_data.R"',
                        dest='input_dir',
                        type=str)
    parser.add_argument('-seed', help='Seed for random shuffling of patients',
                        dest='seed',
                        type=int,
                        default = 1)
    parser.add_argument('-o', help='path to output file',
                        dest='output',
                        type=str)
    parser.add_argument('-cache_dir', help='Directory to save cache',
                        dest='cache_dir',
                        type=str)

    args = parser.parse_args()
    return args

args = parse_args()

print(args.input_dir)

#-------------------------------------------------------------------------------
# 1.2 Configure scnapy prepare working directory
#-------------------------------------------------------------------------------
# set directory to save cache
sc.settings.verbosity = 3
sc.settings.cachedir = "/net/beegfs/cfg/tgac/f.otterloo/GCBLADE/.cache/Lee"

#-------------------------------------------------------------------------------
# 2.1 read Anndata object
#-------------------------------------------------------------------------------
adata_final = sc.read_h5ad(args.input)

input_dir = "/net/beegfs/cfg/tgac/f.otterloo/GCBLADE/data/Lee/results/10X_Counts"

adata = sc.read_10x_mtx(
    input_dir, 
    var_names='gene_symbols',
    cache=True)

#-------------------------------------------------------------------------------
# 3.1 Sum gene expressions per cell type per patient
#-------------------------------------------------------------------------------

# obtain raw gene expression
raw_data = adata.X.toarray()
# obtain patient IDs
patient_ids = list(adata_final.obs.patient)

# initialize dict
simulated_bulk = dict()
# iterate over patients
for patient_id  in sorted(set(patient_ids), key=patient_ids.index):
    # obtain indices of patient
    patient_indices = [index for index, element in enumerate(patient_ids) if element == patient_id]
    # subset raw data
    filtered_data = raw_data[patient_indices]
    # add sum of counts to dict
    summed_counts = np.sum(filtered_data, axis = 0)
    #Normalize by dividing by sum over all genes and scaling to 10k
    normalized_summed_counts = (summed_counts/np.sum(summed_counts)) * 10000
    # store in dict
    simulated_bulk[patient_id] = normalized_summed_counts

output_dict = {'pseudobulk' : simulated_bulk, 'genelist': adata.var_names}
print(output_dict)
#---------------------------------------------------------------------------
# 4.1 Write to file
#-------------------------------------------------------------------------------
with open(args.output, "wb") as out:
    pickle.dump(output_dict, out)
