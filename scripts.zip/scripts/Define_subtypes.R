#!/usr/bin/env Rscript
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# inspect_subtype_full.R
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#
# inspect subtype.full.txt file from cBioportal to check for double or
# missing subtypes
# Author: Florenz van Otterloo (f.j.w.vanotterloo@amsterdamumc.nl)
#
# Usage:
# Rscript 
#
# TODO:
# 1) integrate in GCBLADE pipeline 08-05-2024
# History:
# 30-04-2024: Creation
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# 0.1  Import Libraries
#-------------------------------------------------------------------------------

suppressWarnings(library(tidyverse))
suppressWarnings(library(readr))
suppressWarnings(library(data.table))
suppressWarnings(library(optparse))

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# 1.0  Parse snakemake objects
#-------------------------------------------------------------------------------

#setwd("/net/beegfs/cfg/tgac/f.otterloo/GCBLADE/data/TCGA_STAD/")
#subtypes <- read.delim("Subtype.full.txt", header = TRUE)
#auxiliary_data <- read.delim("nationwidechildrens.org_auxiliary_stad.txt", header = TRUE)
#patient_data <- read.delim("nationwidechildrens.org_clinical_patient_stad.txt",header = TRUE)

option_list = list(
    make_option(c("--subtypes"), action = "store", default = NA, type = 'character', help = "Provide path to file containing subtypes"),
    make_option(c("--auxiliary"), action = "store", default = NA, type = 'character', help = "Provide path to file containing MSI patients according to MLHC staining"),
    make_option(c("--patients"), action = "store", default = NA, type = 'character', help = "Provide path to file containing patient data"),
    make_option(c("-o","--output"), action = "store", default = NA, type = 'character', help = "Place to store corrected subtypes")
)
  
subtypes <- (parse_args(OptionParser(option_list = option_list)))$subtypes
auxiliary <- (parse_args(OptionParser(option_list = option_list)))$auxiliary
patients <- (parse_args(OptionParser(option_list = option_list)))$patients
output <- (parse_args(OptionParser(option_list = option_list)))$output

#-------------------------------------------------------------------------------
# 1.1  Load objects
#-------------------------------------------------------------------------------

subtypes <- read.delim(subtypes, header = TRUE)
auxiliary_data <- read.delim(auxiliary, header = TRUE)
patient_data <- read.delim(patients, header = TRUE)

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# 2.0  check if the annotated subtypes in auxiliary_data and Subtype.full.txt are corresponding
#-------------------------------------------------------------------------------

# make list with IDs that are MSI according to auxiliary_data
MSI_auxiliary_IDs <- auxiliary_data$bcr_patient_barcode[auxiliary_data$mononucleotide_and_dinucleotide_marker_panel_analysis_status == "MSI-H"]

# make list with IDs that are MSI according to Subtype.full.txt
MSI_subtypes_IDs <- subtypes$Patient.ID[subtypes$Subtype == "STAD_MSI"]

# check subtypes in Subtype.full.txt from patients that are MSI accordign to auxiliary_data
subtype_check <- subtypes[subtypes$Patient.ID %in% c(MSI_auxiliary_IDs),]

# change subtypes in Subtype.full to MSI
not_MSI_id <- subtype_check[!subtype_check$Subtype == "STAD_MSI",]
subtypes$Subtype[as.numeric(rownames(not_MSI_id))] <- "STAD_MSI"
MSI_auxiliary_IDs <- MSI_auxiliary_IDs[!MSI_auxiliary_IDs %in% c(not_MSI_id$Patient.ID)]

# add patients where MSI status is known but not in Subtype.full.txt
MSI_missing_IDs <- intersect(MSI_auxiliary_IDs, MSI_subtypes_IDs)
MSI_missing_IDs <- MSI_auxiliary_IDs[!MSI_auxiliary_IDs %in% c(MSI_missing_IDs)]

MSI_to_add <- data.frame(matrix(nrow = length(MSI_missing_IDs), ncol = 3))
colnames(MSI_to_add) <- colnames(subtypes)

MSI_to_add$Study.ID <- subtypes$Study.ID[1]
MSI_to_add$Patient.ID <- MSI_missing_IDs
MSI_to_add$Subtype <- "STAD_MSI"

subtypes <- rbind(subtypes, MSI_to_add)

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# 3.0  save Subtype.full.txt as Subtype.full.corrected.txt
#-------------------------------------------------------------------------------
write.csv(subtypes, file = output, row.names = FALSE)
