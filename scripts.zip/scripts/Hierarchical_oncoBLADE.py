#!/usr/bin/python3
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# Hierarchical_oncoBLADE.py
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#
# Run oncoBLADE with expectations from lower level of celltypes for a given DEG method
#
# Author: Mischa Steketee (m.f.b.steketee@amsterdamumc.nl)
#
# Usage:
"""
python3 scripts/Hierarchical_oncoBLADE.py  \
-i_bulk {input.simulated_bulk} \
-i_sign2 {input.signature_matrices_corrected2} \
-i_sign {input.signature_matrices_corrected} \
-i_DEGs {input.DEGs_data} \
-i_oncoBLADE {input.oncoBLADE_output} \
-parameters {params.Parameters} \
-expectation {wildcards.expectation} \
-hierarchical_level {wildcards.hierarchical_level} \
-cohort 
-o {output.hierarchical_oncoBLADE_output}
"""
#
# TODO:
# 1)

# History:
#  17-4-2024: adapted from BLADE/oncoBLADE.py
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# 0.1  Import Libraries
#-------------------------------------------------------------------------------
import argparse
import pickle
import pandas as pd
import numpy as np
import yaml
import sys
from itertools import chain
import os
os.environ['OPENBLAS_NUM_THREADS'] = '4'
sys.path.insert(1, 'scripts/OncoBLADE/')
from Deconvolution.OncoBLADE import Framework_Iterative

## function to find indices from matches in a list comparison
def matched_index(l1, l2):
    l2 = set(l2)
    return [i for i, el in enumerate(l1) if el in l2]

def intersection(lst1, lst2):
    lst3 = [value for value in lst1 if value in lst2]
    return lst3
#-------------------------------------------------------------------------------
# 1.1 Parse command line arguments
#-------------------------------------------------------------------------------
def parse_args():
    "Parse inputs from commandline and returns them as a Namespace object."
    parser = argparse.ArgumentParser(prog = 'python3 BLADE.py',
        formatter_class = argparse.RawTextHelpFormatter, description =
        '  Create celltype specific signature matrices  ')
    parser.add_argument('-i_bulk', help='path to bulk transcriptome files',
                        dest='input_bulk',
                        type=str)
    parser.add_argument('-i_sign2', help='path to signature matrice subtype2',
                        dest='input_signature2',
                        type=str)
    parser.add_argument('-i_sign', help='path to signature matrices of detailed subtype',
                        dest='input_signature',
                        type=str)
    parser.add_argument('-i_DEGs', help='path to DEG data',
                        dest='input_autogenes',
                        type=str)
    parser.add_argument('-i_oncoBLADE', help='path to lower level oncoBLADE output',
                        dest='input_oncoBLADE',
                        type=str)
    parser.add_argument('-expectation', help='with or without expected tumor fraction',
                        dest='expectation',
                        choices = ['no_expectation','with_expectation'],
                        type=str)
    parser.add_argument('-hierarchical_level', help='hierarchical level for mapping dict',
                        dest='hierarchical_level',
                        type=str)
    parser.add_argument('-parameters', help='path to config file',
                        dest='parameters',
                        type=str)
    parser.add_argument('-cohort', help='which bulk cohort',
                        dest='cohort',
                        choices = ['TCGA', 'simulation'],
                        type=str)
    parser.add_argument('-GSE_IDs', help='cell type level',
                        dest='GSE_split',
                        type=str)
    parser.add_argument('-o', help='path to output file',
                        dest='output',
                        type=str)
    args = parser.parse_args()
    return args

args = parse_args()
#-------------------------------------------------------------------------------
# 1.2 Read Parameters
#-------------------------------------------------------------------------------
# read configuration file
with open(args.parameters) as infile:
    config = yaml.load(infile, Loader=yaml.FullLoader)
    
Alpha = config["BLADE"]["Parameters"]["Alpha"]
Kappa0 =  config["BLADE"]["Parameters"]["Kappa0"]
SY = config["BLADE"]["Parameters"]["SY"]
Nrep = config["BLADE"]["Parameters"]["Nrep"]
Nrepfinal = config["BLADE"]["Parameters"]["Nrepfinal"]
Njob = config["BLADE"]["Parameters"]["Njob"]
expectation = args.expectation
cohort = args.cohort
GSE_split = args.GSE_split

#-------------------------------------------------------------------------------
# 2.1 Read data
#-------------------------------------------------------------------------------
# read bulk data
with open(args.input_bulk, "rb") as infile:
    bulk = pickle.load(infile)
    
# read signatures
with open(args.input_signature2, "rb") as infile:
    signature2 = pickle.load(infile)

with open(args.input_signature, "rb") as infile:
    signature = pickle.load(infile)

## Read oncoBLADE output from lower level
with open(args.input_oncoBLADE, "rb") as infile:
    oncoBLADE = pickle.load(infile)

# read GSE_split, if used
GSE_split_used = False
if args.GSE_split:
    GSE_IDs = pd.read_csv(GSE_split)
    selected_IDs = GSE_IDs['x']
    GSE_split_used = True  
    
# read selected genes
selected_genes = pd.read_csv(args.input_autogenes, sep = "\t")

#-------------------------------------------------------------------------------
# 2.2 Select DEGs
#-------------------------------------------------------------------------------
autogenes = selected_genes.iloc[:,0]
#print(list(autogenes))

if cohort == "TCGA":
    genes = intersection(bulk[1], list(autogenes))
elif cohort == "simulation":
    bulk = {"pseudobulk":bulk['pseudobulk'], "genelist":bulk['genelist']}
    #print(bulk_data['genelist'])
    genes = intersection(list(autogenes), bulk['genelist']) 
    
#-------------------------------------------------------------------
# 3.1 Prepare Mu,Omega and Y
#-------------------------------------------------------------------------------
## Create dfs for BLADE input
Mu = pd.DataFrame(signature['Mu'], index = signature['Genelist'], columns = signature['celltype_list'])
Omega = pd.DataFrame(signature['Omega'], index = signature['Genelist'], columns = signature['celltype_list'])
if cohort == "TCGA":
    Y = pd.DataFrame(bulk[0], index = bulk[1] )
elif cohort == "simulation":
    Y = pd.DataFrame(bulk['pseudobulk'], index = bulk['genelist'] )
    if GSE_split_used:
        Y = Y[selected_IDs]

## subset to only use DEG genes
Mu = Mu.loc[genes,]
Omega = Omega.loc[genes,]
Y = Y.loc[genes,]

## select only genes that occur once  in Y
lst = list(Y.index)
bulk2 = list(set([x for x in lst if lst.count(x)==1]))
Mu = Mu.loc[bulk2,]
Omega = Omega.loc[bulk2,]
Y = Y.loc[bulk2,]

# Sanity checks
if cohort == "TCGA":
    if len(signature['GeneList_hvg']) >= len(signature['Genelist']):
        raise ValueError("Mistake in assigning genelists in Create_signature")
    elif len(bulk[1]) != len(bulk[0][next(iter(bulk[0]))]):
        raise ValueError("Genes do not correspond to their expression levels")
    elif not(any(Mu.index == Y.index)):
        raise ValueError("signature and bulk genes don't align")
    elif 'Expected_TF' in locals(): # only if Expected_TF exists
        if not(any(Expected_TF['sample'] == Y.columns)):
            raise ValueError("Expected tumor fractions and bulk patients don't align")
    else:
        print("Sanity checks passed")
elif cohort == "simulation":
    if len(signature['GeneList_hvg']) >= len(signature['Genelist']):
        raise ValueError("Mistake in assigning genelists in Create_signature")
    elif len(bulk['genelist']) != len(bulk['pseudobulk'][next(iter(bulk['pseudobulk']))]):
        raise ValueError("Genes do not correspond to their expression levels")
    elif not(any(Mu.index == Y.index)):
        raise ValueError("signature and bulk genes don't align")
    elif 'Expected_TF' in locals(): # only if Expected_TF exists
        if not(all(Expected_TF.index == Y.columns)):
            raise ValueError("Expected tumor fractions and bulk patients don't align")
    else:
        print("Sanity checks passed")
          
## Add small number so Omega values are not zero
Omega = Omega + 0.01

#-------------------------------------------------------------------------------
# 3.2 Prepare Alpha0: set Alpha0 to number of obs in signature / 2 for each celltype
#-------------------------------------------------------------------------------
# Intialize Alpha0 (Ngene x Ncell)
Alpha0 = np.empty((len(Mu),len(signature['celltype_list'])))
for i,celltype in enumerate(signature['celltype_list']):
    Alpha0[:,i] = signature['celltype_abundances'][celltype] / 2

#-------------------------------------------------------------------------------
# 3.3 Prepare Expectation from lower level oncoBLADE output
#-------------------------------------------------------------------------------
## Get estimates from oncoBLADE
obj = oncoBLADE['final_obj']

print(Y.columns)
print(signature2['celltype_list'])

estimated_cf = obj.ExpF(obj.Beta)
df_estimated_cf = pd.DataFrame(estimated_cf, columns = signature2['celltype_list'], index = Y.columns)

print(estimated_cf)
print(df_estimated_cf)
#print(BREAK_POINT)

## Determine lowest estimated celltype and set expectation to NAN for computational reasons
min_celltype = (df_estimated_cf.mean() == min(df_estimated_cf.mean())).values

df_estimated_cf.iloc[:,min_celltype] = float('NAN')

## Create mapping dict from level 3 back to level 2
mapping_dict = {'Memory B cell' : 'Lymphoid cell', 'Naive B cell' : 'Lymphoid cell', 'Epithelial cell' : 'Epithelial cell',
                'Mast cell' : 'Mast cell', 'Endocrine cell' : 'Endocrine cell', 'CD4+ T cell' : 'Lymphoid cell',
                'NK cell' : 'Lymphoid cell', 'CD8+ T cell' : 'Lymphoid cell', 'Endothelial cell' : 'Endothelial cell',
                'Treg' : 'Lymphoid cell', 'iCAF' : 'Fibroblast', 'myCAF' : 'Fibroblast', 'Macrophage M2' : 'Macrophage',
                'Macrophage M1' : 'Macrophage', 'Neutrophil' : 'Myeloid cell', 'DC' : 'Myeloid cell', 'Plasma cell' : 'Lymphoid cell'}

# # Intialize Group where group is 10 celltypes of lower level (nGroup x nCelltypes)
Group = np.zeros((len(signature2['celltype_list']), len(signature['celltype_list'])))


## Group detailed celltypes into their coarse groups # Create group
for i,celltype in enumerate(signature['celltype_list']):
    ## Get group celltype and its index
    group_celltype = mapping_dict[celltype]
    group_index = signature2['celltype_list'].index(group_celltype)

    ## Put detailed subtype in right group
    Group[group_index, i] = 1

print(Group)
## Create Expectation matrix (nSample x nGroup) from oncoBLADE estimates
Expectation = df_estimated_cf.to_numpy()

## Put Group and expectation in a dict together
Expected = {
      'Group': Group,
      'Expectation': Expectation
}
#-------------------------------------------------------------------------------
# 4.1 Run BLADE
#-------------------------------------------------------------------------------
## run with or without expectation based on cmdline
if expectation == "no_expectation":
  Expected = None

#print(Expected)  
#print(BREAK_POINT)
  
np.set_printoptions(threshold=np.inf)
print(Expectation)
print(Nrepfinal)
# Run BLADE
final_obj, best_obj, best_set, outs = Framework_Iterative(
            Mu.to_numpy(), Omega.to_numpy(),Y.to_numpy(),
            Alpha=Alpha, Alpha0=Alpha0, 
            Kappa0=Kappa0, sY=SY,
            Nrep=Nrep, Njob=Njob, IterMax=Nrepfinal, Expectation = Expected)

BLADE_output = {
    'final_obj': final_obj,
    'best_obj': best_obj,
    'best_set': best_set,
    'outs' : outs,
    'genes' : genes
}

print(type(BLADE_output))

#-------------------------------------------------------------------------------
# 5.1 Write to file
#-------------------------------------------------------------------------------
with open(args.output, "wb") as out:
    pickle.dump(BLADE_output, out)
