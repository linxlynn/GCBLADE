#!/usr/bin/env Rscript
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# divide_STAD_combined.R
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#
# divide STAD_normalized_combined_estimated_cf.csv into 4 subtype files
#
#
# Usage:
# R divide_STAD_combined.R
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# 0.1  Import Libraries
#-------------------------------------------------------------------------------

suppressMessages(library(optparse))

#-------------------------------------------------------------------------------
# 1.0 Parse arguments
#-------------------------------------------------------------------------------
option_list = list(
    make_option(c("--STAD_cf"), action = "store", default = NA, type = 'character', help = "Provide path to file containing STAD cell fractions"),
    make_option(c("--if_normalized"), action = "store", default = "YES", type = 'character', help = "Specify whether the data is normalized"),
    make_option(c("--cell_level"), action = "store", default = NA, type = 'character', help = "Specify major or minor cell types"),
    make_option(c("--CIN_cf"), action = "store", default = NA, type = 'character', help = "Provide path to file containing CIN cell fractions"),
    make_option(c("--EBV_cf"), action = "store", default = NA, type = 'character', help = "Provide path to file containing EBV cell fractions"),
    make_option(c("--GS_cf"), action = "store", default = NA, type = 'character', help = "Provide path to file containing GS cell fractions"),
    make_option(c("--MSI_cf"), action = "store", default = NA, type = 'character', help = "Provide path to file containing MSI cell fractions"))

args <- parse_args(OptionParser(option_list = option_list))

STAD_cf <- args$STAD_cf
if_normalized <- args$if_normalized
cell_level <- args$cell_level
subtype_output <- list(
    CIN = args$CIN_cf,
    EBV = args$EBV_cf,
    GS = args$GS_cf,
    MSI = args$MSI_cf
)

#-------------------------------------------------------------------------------
# 2.0 Separate into subtypes
#-------------------------------------------------------------------------------
combined_data <- read.csv(STAD_cf)

subtypes <-c("CIN", "EBV", "GS", "MSI")

for (subtype in subtypes) {
    # Filter data for current subtype
    subtype_data <- combined_data[combined_data$subtype == subtype, ]

    if (if_normalized == "NO" & cell_level == "cell_type2") {
        # Integration into major cell types
        subtype_data$Fibroblast <- rowSums(subtype_data[,c("iCAF", "myCAF")])
        subtype_data$Macrophage <- rowSums(subtype_data[, c("Macrophage.M1", "Macrophage.M2")])
        subtype_data$Myeloid.cell <- rowSums(subtype_data[, c("Neutrophil", "DC")])
        subtype_data$Lymphoid.cell <- rowSums(subtype_data[, c("CD4..T.cell", "CD8..T.cell", "Memory.B.cell", "NK.cell", "Naive.B.cell", "Plasma.cell", "Treg")])

    }
    
    write.csv(subtype_data, file = subtype_output[[subtype]], row.names = FALSE)

}


