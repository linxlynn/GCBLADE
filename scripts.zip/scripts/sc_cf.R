
library(dplyr)
library(tidyr)
library(ggplot2)

# Read CSV files while keeping row names
true_frac <- read.csv("/net/beegfs/cfg/tgac/xlin/florenz_copy/GCBLADE/data/Lee/results/oncoBLADE/True_fractions_cell_type2.csv", row.names = 1)
subtype <- read.csv("/net/beegfs/cfg/tgac/xlin/florenz_copy/GCBLADE/data/Lee/sc_subtype_mapping/updated_single_cell_atlas.csv", row.names = 1)


# Ensure subtype mapping is correctly aligned by row names
true_frac$Subtype <- subtype[rownames(true_frac), "Subtype"]

# Select only DC and Subtype columns
dc_data <- true_frac[, c("Subtype", "DC")]

# Create the plot
dc_plot <- ggplot(dc_data, aes(x = Subtype, y = DC, fill = Subtype)) +
  geom_boxplot(outlier.shape = NA, alpha = 0.7) +
  geom_jitter(width = 0.2, alpha = 0.5) +
  theme_minimal() +
  labs(title = "DC Cell Fractions Across Subtypes",
       x = "Subtype",
       y = "DC Fraction") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

ggsave("/net/beegfs/cfg/tgac/xlin/florenz_copy/GCBLADE/data/Lee/results/evaluate/results_consensus/with_expectation/state/simulation/DC_cf.png", 
       plot = dc_plot, width = 8, height = 6)
