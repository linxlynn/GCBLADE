#!/usr/bin/env Rscript
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# subtype_difference.R
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#
# check whether differences across subtypes are consistent for 10 runs
#
# Usage:
# R subtype_difference.R
#
#
#
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# 0.1  Import Libraries
#-------------------------------------------------------------------------------

suppressMessages({
    library(tidyverse)
    library(optparse)
    library(ggplot2)
    library(effsize)
    library(patchwork)
})

option_list <- list(
    make_option("--CIN_cf", type="character", help="Provide path to normalized k folds CIN file"),
    make_option("--EBV_cf", type="character", help="Provide path to normalized k folds EBV file"),
    make_option("--GS_cf", type="character", help="Provide path to normalized k folds GS file"),
    make_option("--MSI_cf", type="character", help="Provide path to normalized k folds MSI file"),
    make_option("--result", type="character", help="Provide path for result file"),
    make_option("--plots_dir", type="character", help="Directory to save visualization plots")
)

args <- parse_args(OptionParser(option_list=option_list))

CIN_cf <- args$CIN_cf
EBV_cf <- args$EBV_cf
GS_cf <- args$GS_cf
MSI_cf <- args$MSI_cf
result <- args$result
plots_dir <- args$plots_dir

dir.create(plots_dir, showWarnings = FALSE)

#-------------------------------------------------------------------------------
# 2.0 Consistency of subtype differences across runs
#-------------------------------------------------------------------------------

# Load file
CIN <- read.csv(CIN_cf)
EBV <- read.csv(EBV_cf)
GS <- read.csv(GS_cf)
MSI <- read.csv(MSI_cf)

k_values <- 1:10
cell_types <- c("Lymphoid.cell", "Mast.cell", "Endocrine.cell",
                "Endothelial.cell", "Fibroblast", "Macrophage", "Myeloid.cell")

minor_cell_types <- c("CD4..T.cell", "CD8..T.cell", "DC", "Endocrine.cell",
                      "Endothelial.cell", "Macrophage.M1", "Macrophage.M2",
                      "Mast.cell", "Memory.B.cell", "Naive.B.cell", "NK.cell",
                      "Neutrophil", "Plasma.cell", "Treg", "iCAF", "myCAF")

# for absolute frac
simplified_ct1 <- c("Endothelial.cell", "Macrophage.M1", "Macrophage.M2", "iCAF", "myCAF")

# for minor cell types simplified
simplified_ct2 <- c("CD4..T.cell", "DC",
                    "Endothelial.cell", "Macrophage.M2",
                    "Mast.cell", "Memory.B.cell", "Naive.B.cell",
                    "Neutrophil", "Treg")

# for better view
simplified_ct3 <- c("DC")

subtypes <- list(
  CIN = CIN,
  EBV = EBV,
  GS = GS,
  MSI = MSI
)

# Cohen d function
cohens_d <- function (mean1, sd1, n1, mean2, sd2, n2) {
    pooled_sd <- sqrt((((n1 - 1) * sd1^2) + ((n2 - 1) * sd2^2)) / (n1 + n2 - 2))
    d <- (mean1 - mean2) / pooled_sd
    return (d)
}

colors <- c("#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7", "#999999")

# Initialize an empty list to store Cohen's d results
all_cohens_d_results <- list()

# Loop through each selected subtype

#---------------------------------------------------------------------
# major cell types
#---------------------------------------------------------------------
for (selected_subtype in names(subtypes)) {
    selected_data <- subtypes[[selected_subtype]]
  
    # Loop through other subtypes for comparison
    for (compare_subtype in setdiff(names(subtypes), selected_subtype)) {
        compare_data <- subtypes[[compare_subtype]]
    
        cohens_d_results_list <- list()
    
        # Loop through each cell type and calculate Cohen's d
        index <- 1
        for (ct in cell_types) {
            for (k in k_values) {
                if (ct %in% colnames(selected_data) & ct %in% colnames(compare_data)) {
                    selected_run <- selected_data %>% filter(k == !!k) %>% pull(ct)
                    compare_run <- compare_data %>% filter(k == !!k) %>% pull(ct)
        
                    mean1 <- mean(selected_run)               
                    sd1 <- sd(selected_run)
                    n1 <- length(selected_run)
        
                    mean2 <- mean(compare_run)
                    sd2 <- sd(compare_run)
                    n2 <- length(compare_run)
        
                    # Calculate Cohen's d
                    d <- cohens_d(mean1, sd1, n1, mean2, sd2, n2)
        
                    cohens_d_results_list[[index]] <- data.frame(
                        Subtype = selected_subtype,
                        Comparison = compare_subtype,
                        Run = k,
                        Cell_Type = ct,
                        Cohens_D = d
                    )                    
                     
                    index <- index + 1
                } else {
                    next
                }
                

            }
        }
    
        # Append results to the main data frame
        all_cohens_d_results <- append(all_cohens_d_results, cohens_d_results_list)
    }
}

#--------------------------------------------------------------------------------------
# minor cell types
#--------------------------------------------------------------------------------------

## for (selected_subtype in names(subtypes)) {
##     selected_data <- subtypes[[selected_subtype]]
  
##     # Loop through other subtypes for comparison
##     for (compare_subtype in setdiff(names(subtypes), selected_subtype)) {
##         compare_data <- subtypes[[compare_subtype]]
    
##         cohens_d_results_list <- list()
    
##         # Loop through each cell type and calculate Cohen's d
##         index <- 1
##         for (ct in minor_cell_types) {
##             for (k in k_values) {
##                 if (ct %in% colnames(selected_data) & ct %in% colnames(compare_data)) {
##                     selected_run <- selected_data %>% filter(k == !!k) %>% pull(ct)
##                     compare_run <- compare_data %>% filter(k == !!k) %>% pull(ct)
        
##                     mean1 <- mean(selected_run)               
##                     sd1 <- sd(selected_run)
##                     n1 <- length(selected_run)
        
##                     mean2 <- mean(compare_run)
##                     sd2 <- sd(compare_run)
##                     n2 <- length(compare_run)
        
##                     # Calculate Cohen's d
##                     d <- cohens_d(mean1, sd1, n1, mean2, sd2, n2)
        
##                     cohens_d_results_list[[index]] <- data.frame(
##                         Subtype = selected_subtype,
##                         Comparison = compare_subtype,
##                         Run = k,
##                         Cell_Type = ct,
##                         Cohens_D = d
##                     )                    
                     
##                     index <- index + 1
##                 } else {
##                     next
##                 }
                

##             }
##         }
    
##         # Append results to the main data frame
##         all_cohens_d_results <- append(all_cohens_d_results, cohens_d_results_list)
##     }
## }

#--------------------------------------------------------------------------
# simplified cell types
#-------------------------------------------------------------------------- 
## for (selected_subtype in names(subtypes)) {
##     selected_data <- subtypes[[selected_subtype]]
  
##     # Loop through other subtypes for comparison
##     for (compare_subtype in setdiff(names(subtypes), selected_subtype)) {
##         compare_data <- subtypes[[compare_subtype]]
    
##         cohens_d_results_list <- list()
    
##         # Loop through each cell type and calculate Cohen's d
##         index <- 1
##         for (ct in simplified_ct3) {
##             for (k in k_values) {
##                 if (ct %in% colnames(selected_data) & ct %in% colnames(compare_data)) {
##                     selected_run <- selected_data %>% filter(k == !!k) %>% pull(ct)
##                     compare_run <- compare_data %>% filter(k == !!k) %>% pull(ct)
        
##                     mean1 <- mean(selected_run)               
##                     sd1 <- sd(selected_run)
##                     n1 <- length(selected_run)
        
##                     mean2 <- mean(compare_run)
##                     sd2 <- sd(compare_run)
##                     n2 <- length(compare_run)
        
##                     # Calculate Cohen's d
##                     d <- cohens_d(mean1, sd1, n1, mean2, sd2, n2)
        
##                     cohens_d_results_list[[index]] <- data.frame(
##                         Subtype = selected_subtype,
##                         Comparison = compare_subtype,
##                         Run = k,
##                         Cell_Type = ct,
##                         Cohens_D = d
##                     )                    
                     
##                     index <- index + 1
##                 } else {
##                     next
##                 }
                

##             }
##         }
    
##         # Append results to the main data frame
##         all_cohens_d_results <- append(all_cohens_d_results, cohens_d_results_list)
##     }
## }


#------------------------------------------------------------------------
# Combine all results into a single data frame
#------------------------------------------------------------------------
final_cohens_d_results <- do.call(rbind, all_cohens_d_results)
write.csv(final_cohens_d_results, result, row.names = FALSE)

# Remove redundant pairs
unique_cohens_d_results <- final_cohens_d_results %>%
    mutate(Pair = paste0(pmin(Subtype, Comparison), "_", pmax(Subtype, Comparison))) %>%
    distinct(Pair, Run, Cell_Type, .keep_all = TRUE)

#-------------------------------------------------------------------------------
# ONE BOXPLOT FOR ALL CELL TYPES
#-------------------------------------------------------------------------------
# Compute median y-values for labels
boxplot_labels <- unique_cohens_d_results %>%
    group_by(Cell_Type, Pair) %>%
    summarize(y_pos = median(Cohens_D), .groups = "drop")

boxplot <- ggplot(unique_cohens_d_results, aes(x = Cell_Type, y = Cohens_D, fill = Pair)) +
    geom_boxplot(outlier.shape = NA, width = 0.6, size = 0.6, position = position_dodge(width = 0.8)) +
    geom_jitter(position = position_dodge(width = 0.8), alpha = 0.3, size = 0.5) +
    # geom_text(data = boxplot_labels, aes(x = Cell_Type, y = y_pos + 0.15, label = Pair), 
              # position = position_dodge(width = 0.8), size = 1.5) +
    scale_fill_manual(values = colors) +
    labs(
        x = "Cell Type",
        y = "Cohen's d",
        fill = "Subtype Pair") +
    theme_minimal() +
    theme(
        axis.text.x = element_text(angle = 45, hjust = 1),
        legend.position = "bottom") +
    geom_hline(yintercept = 2.8, linetype = "dashed", color = "#E69F00", size = 0.8, alpha = 0.5) + 
    geom_hline(yintercept = -2.8, linetype = "dashed", color = "#E69F00", size = 0.8, alpha = 0.5)
    #geom_hline(yintercept = 0.5, linetype = "dotdash", color = "#56B4E9", size = 0.8, alpha = 0.5) +
    #geom_hline(yintercept = -0.5, linetype = "dotdash", color = "#56B4E9", size = 0.8, alpha = 0.5)


ggsave(filename = file.path(plots_dir, paste0("boxplot_cohens_d_comparison.png")),
       plot = boxplot,
       width = 8, height = 6, dpi = 300)


#-------------------------------------------------------------------------------
# CREATE PLOT FOR EACH CELL TYPE AND SELECTED SUBTYPE
#-------------------------------------------------------------------------------

# major cell types
for (ct in cell_types) {
    for (selected_subtype in names(subtypes)) {
        # Filter data for the selected subtype and cell type
        plot_data <- final_cohens_d_results %>%
            filter(Cell_Type == ct & Subtype == selected_subtype) %>%
            mutate(Comparison_Label = paste(Subtype, Comparison, sep = "-")) # add a new column

        # Create the plot
        plot <- ggplot(plot_data,
                       aes(x = Run, y = Cohens_D, color = Comparison_Label, group = Comparison_Label)) +
            geom_line(size = 1) + 
            geom_point(size = 2) +
            scale_x_continuous(breaks = 1:10) +
            scale_color_manual(values = colors) + 
            labs(
                x = "Run",
                y = "Cohen's d",
                color = "Compared Subtype") +
            theme_minimal() +
            theme(
                panel.grid.major = element_line(color = "gray90")
            )

        ggsave(
            filename = file.path(plots_dir, paste0("Cohens_d_comparison_", selected_subtype, "_", ct, ".png")),
            plot = plot,
            width = 8, height = 6, dpi = 300)
        
    }
    
}

## # minor cell types
## for (ct in minor_cell_types) {
##     for (selected_subtype in names(subtypes)) {
##         # Filter data for the selected subtype and cell type
##         plot_data <- final_cohens_d_results %>%
##             filter(Cell_Type == ct & Subtype == selected_subtype) %>%
##             mutate(Comparison_Label = paste(Subtype, Comparison, sep = "-")) # add a new column

##         # Create the plot
##         plot <- ggplot(plot_data,
##                        aes(x = Run, y = Cohens_D, color = Comparison_Label, group = Comparison_Label)) +
##             geom_line(size = 1) + 
##             geom_point(size = 2) +
##             scale_x_continuous(breaks = 1:10) +
##             labs(
##                 x = "Run",
##                 y = "Cohen's d",
##                 title = paste("Comparisons of", selected_subtype, "against other subtypes for cell type", ct),
##                 color = "Compared Subtype") +
##             theme_minimal() +
##             theme(
##                 panel.grid.major = element_line(color = "gray90")
##             )

##         ggsave(
##             filename = file.path(plots_dir, paste0("Cohens_d_comparison_", selected_subtype, "_", ct, ".png")),
##             plot = plot,
##             width = 8, height = 6, dpi = 300)
        
##     }
    
## }

#-------------------------------------------------------------------------------
# USING CLIFF DELTA (NOT USED)
#-------------------------------------------------------------------------------

## all_cliff_delta_results <- data.frame()

## # Loop through each selected subtype
## for (selected_subtype in names(subtypes)) {
##     selected_data <- subtypes[[selected_subtype]]
  
##     # Loop through other subtypes for comparison
##     for (compare_subtype in setdiff(names(subtypes), selected_subtype)) {
##         compare_data <- subtypes[[compare_subtype]]

##         cliff_delta_results_list <- list()
    
##         # Loop through each cell type and calculate cliff delta
##         index <- 1
##         for (ct in cell_types) {
##             for (k in k_values) {
##                 selected_run <- selected_data %>% filter(k == k) %>% pull(ct)
##                 compare_run <- compare_data %>% filter(k == k) %>% pull(ct)

##                 cliff_d <- cliff.delta(selected_run, compare_run)
        
##                 # Store the result

##                 cliff_delta_results_list[[index]] <- data.frame(
##                     Subtype = selected_subtype,
##                     Comparison = compare_subtype,
##                     Run = k,
##                     Cell_Type = ct,
##                     Cliff_Delta = cliff_d$estimate,
##                     Magnitude = cliff_d$magnitude
##                 )
                
##                 index <- index + 1
##             }
            
##         }
        
##         # Append results to the main data frame
##         all_cliff_delta_results <- append(all_cliff_delta_results, cliff_delta_results_list)
##     }
    
## }

## all_cliff_delta_results <- bind_rows(all_cliff_delta_results)
## write.csv(all_cliff_delta_results, result, row.names = FALSE)

## # Create plot for each cell type and selected subtype
## for (ct in cell_types) {
##     for (selected_subtype in names(subtypes)) {
##         # Filter data for the selected subtype and cell type
##         plot_data <- all_cliff_delta_results %>%
##             filter(Cell_Type == ct & Subtype == selected_subtype) %>%
##             mutate(Comparison_Label = Comparison) # add a new column

##         # Create the plot
##         plot <- ggplot(plot_data,
##                        aes(x = Run, y = Cliff_Delta, color = Comparison_Label, group = Comparison_Label)) +
##             geom_line(size = 1) + 
##             geom_point(size = 2) +
##             scale_x_continuous(breaks = 1:10) +
##             labs(
##                 x = "Run",
##                 y = "Cliff's Delta",
##                 title = paste("Comparisons of", selected_subtype, "against other subtypes for cell type", ct),
##                 color = "Compared Subtype") +
##             theme_minimal() +
##             theme(axis.text.x = element_text(angle = 45, hjust = 1),
##                   panel.grid.major = element_line(color = "gray90"),
##                   panel.grid.minor = element_blank())

##         ggsave(
##             filename = file.path(plots_dir, paste0("Cliffs_Delta_comparison_", selected_subtype, "_", ct, ".png")),
##             plot = plot,
##             width = 8, height = 6, dpi = 300)
        
##     }
    
## }
