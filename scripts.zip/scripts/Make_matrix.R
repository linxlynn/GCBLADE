#!/usr/bin/env Rscript
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# Make_matrix.R
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#
# Convert seurat from lee et al. to matrix.mtx.gz
# Author: Florenz van Otterloo (f.j.w.vanotterloo@amsterdamumc.nl)
#
# Usage:
# Rscript Make_matrix.R \
# -i {input.seurat_phenotyped} \
# -o {output.matrix} \
#
# TODO:
# History:
# 09-05-2024: Creation
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# 0.1  Import Libraries
#--------------------------------------------------------------------------------

suppressMessages(library(dplyr))
suppressMessages(library(Seurat))
suppressMessages(library(stringr))
suppressMessages(library(Matrix))    
suppressMessages(library(DropletUtils))
suppressMessages(library(optparse))

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# 1.0  Parse snakemake objects 
#--------------------------------------------------------------------------------

option_list = list(
    make_option(c("-i", "--input"), action = "store", default = NA, type = "character", help = "Provide path to file containing Seurat object"),
    make_option(c("-o", "--output"), action = "store", default = NA, type = "character", help = "Provide directory to matrix object")
)

args <- parse_args(OptionParser(option_list = option_list))

input_file = args$input                 
output = args$output


#--------------------------------------------------------------------------------
# 1.1  load object 
#--------------------------------------------------------------------------------

load(file = input_file)

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# 2.0  inspect object 
#--------------------------------------------------------------------------------

# selecting detailed celltypes and removing apCAF1,2
celltypes <- unique(GC_seuratObj$cell_type2)
celltypes <- celltypes[!celltypes %in% c("apCAF1", "apCAF2")]

# select single cells that are apCAF1,2 to be remove
to_remove <- colnames(GC_seuratObj)[!GC_seuratObj$cell_type2 %in% celltypes]
GC_seuratObj_filtered <- GC_seuratObj[,!colnames(GC_seuratObj) %in% to_remove]

# rename iCAF1,2,3 to iCAF
GC_seuratObj_filtered$cell_type2[GC_seuratObj_filtered$cell_type2 == "iCAF3"] <- "iCAF"
GC_seuratObj_filtered$cell_type2[GC_seuratObj_filtered$cell_type2 == "iCAF2"] <- "iCAF"
GC_seuratObj_filtered$cell_type2[GC_seuratObj_filtered$cell_type2 == "iCAF1"] <- "iCAF"

# rename myCAF1,2 to myCAF
GC_seuratObj_filtered$cell_type2[GC_seuratObj_filtered$cell_type2 == "myCAF1"] <- "myCAF"
GC_seuratObj_filtered$cell_type2[GC_seuratObj_filtered$cell_type2 == "myCAF2"] <- "myCAF"

#-------------------------------------------------------------------------------
# 2.1 make counts matrix
#-------------------------------------------------------------------------------

# retrieve counts matrix from seurat object 
counts <- as.matrix(GC_seuratObj_filtered@assays$RNA@counts)
# make sparse matrix
counts <- as(counts, "dgCMatrix")
# obtain cell ids
cell_ids <- colnames(counts)
# obtain gene symbols
gene_symbols <- rownames(counts)


#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# 3.0 make counts matrix
#-------------------------------------------------------------------------------
print("saving matrix, this may take a while")
write10xCounts(output, counts, gene.symbol=gene_symbols, barcodes=cell_ids, version='3', overwrite = T)


