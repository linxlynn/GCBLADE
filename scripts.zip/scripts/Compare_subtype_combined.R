#!/usr/bin/env Rscript
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# Compare_subtype_combined.R
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#
# compare the cell fractions per subtype when data is given combined
#
#
# Usage:
# R Compare_subtype_combined.R
#
# TODO:
# 
# History:
# 25-10-2024: adapted from Combined_subtype_cf.R
#
#
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# 0.1  Import Libraries
#-------------------------------------------------------------------------------
suppressMessages(library(readxl))
suppressMessages(library(dplyr))
library(tidyr)
library(ggplot2)
library(optparse)
library(rstatix)
library(ggpubr)

#-------------------------------------------------------------------------------
# 1.0 Parse snakemake objects
#-------------------------------------------------------------------------------
option_list = list(
    make_option(c("--STAD_cf"), action = "store", default = NA, type = 'character', help = "Path to the file STAD_ALL"),
    make_option(c("--subtype_full"), action = "store", default = NA, type = 'character', help = "Path to TCGA full subtype"),
    make_option(c("--cell_level"), action = "store", default = NA, type = 'character', help = "Specify 'simple' or 'detailed' model"),
    make_option(c("--output_simple"), action = "store", default = NA, type = 'character', help = "Path to output plot for the simple model"),
    make_option(c("--output_detailed"), action = "store", default = NA, type = 'character', help = "Path to output plot for the detailed model"),
    make_option(c("--output_norm_simple"), action = "store", default = NA, type = 'character', help = "provide path to output normalized plot either simple or cumulative detailed model"),
    make_option(c("--output_norm_detailed"), action = "store", default = NA, type = 'character', help = "provide path to output normalized plot detailed model")
)

args <- parse_args(OptionParser(option_list = option_list))

STAD_cf <- args$STAD_cf
subtype_full <- args$subtype_full
cell_level <- args$cell_level
output_simple <- args$output_simple
output_detailed <- args$output_detailed
output_norm_simple <- args$output_norm_simple
output_norm_detailed <- args$output_norm_detailed

#-------------------------------------------------------------------------------
# 1.1 Load and separate cell fractions by subtype
#-------------------------------------------------------------------------------
STAD_cf <- read.csv(STAD_cf)

subtype_full <- read.csv(subtype_full)
subtype_full$barcode <- gsub("-", ".", subtype_full$Patient.ID)

STAD_cf <- merge(STAD_cf, subtype_full, by = "barcode")

CIN_cf <- STAD_cf[STAD_cf$Subtype == "STAD_CIN",]
EBV_cf <- STAD_cf[STAD_cf$Subtype == "STAD_EBV",]
GS_cf <- STAD_cf[STAD_cf$Subtype == "STAD_GS",]
MSI_cf <- STAD_cf[STAD_cf$Subtype == "STAD_MSI",]

#-------------------------------------------------------------------------------
# 2.0 sum minor celltypes to major celltypes 
#-------------------------------------------------------------------------------

if (cell_level == "cell_type2"){
    # sum fibroblasts
    CIN_cf$Fibroblast <- rowSums(CIN_cf[, c("iCAF", "myCAF")])
    EBV_cf$Fibroblast <- rowSums(EBV_cf[, c("iCAF", "myCAF")])
    GS_cf$Fibroblast <- rowSums(GS_cf[, c("iCAF", "myCAF")])
    MSI_cf$Fibroblast <- rowSums(MSI_cf[, c("iCAF", "myCAF")])

    # sum macrophages
    CIN_cf$Macrophage <- rowSums(CIN_cf[, c("Macrophage.M1", "Macrophage.M2")])
    EBV_cf$Macrophage <- rowSums(EBV_cf[, c("Macrophage.M1", "Macrophage.M2")])
    GS_cf$Macrophage <- rowSums(GS_cf[, c("Macrophage.M1", "Macrophage.M2")])
    MSI_cf$Macrophage <- rowSums(MSI_cf[, c("Macrophage.M1", "Macrophage.M2")])

    # sum myeloid cells
    CIN_cf$Myeloid.cell <- rowSums(CIN_cf[, c("Neutrophil", "DC")])
    EBV_cf$Myeloid.cell <- rowSums(EBV_cf[, c("Neutrophil", "DC")])
    GS_cf$Myeloid.cell <- rowSums(GS_cf[, c("Neutrophil", "DC")])
    MSI_cf$Myeloid.cell <- rowSums(MSI_cf[, c("Neutrophil", "DC")])

    # sum lymphoid cells
    CIN_cf$Lymphoid.cell <- rowSums(CIN_cf[, c("CD4..T.cell", "CD8..T.cell", "Memory.B.cell",
                                               "NK.cell", "Naive.B.cell", "Plasma.cell", "Treg")])
    EBV_cf$Lymphoid.cell <- rowSums(EBV_cf[, c("CD4..T.cell", "CD8..T.cell", "Memory.B.cell",
                                               "NK.cell", "Naive.B.cell", "Plasma.cell", "Treg")])
    GS_cf$Lymphoid.cell <- rowSums(GS_cf[, c("CD4..T.cell", "CD8..T.cell", "Memory.B.cell",
                                               "NK.cell", "Naive.B.cell", "Plasma.cell", "Treg")])
    MSI_cf$Lymphoid.cell <- rowSums(MSI_cf[, c("CD4..T.cell", "CD8..T.cell", "Memory.B.cell",
                                               "NK.cell", "Naive.B.cell", "Plasma.cell", "Treg")])
}

# sum all immune cells for both simple and detailed models, uncomment if want immune cells combined
## CIN_cf$Immune.cell <- rowSums(CIN_cf[, c("Lymphoid.cell", "Macrophage", "Mast.cell", "Myeloid.cell")])
## EBV_cf$Immune.cell <- rowSums(EBV_cf[, c("Lymphoid.cell", "Macrophage", "Mast.cell", "Myeloid.cell")])
## GS_cf$Immune.cell <- rowSums(GS_cf[, c("Lymphoid.cell", "Macrophage", "Mast.cell", "Myeloid.cell")])
## MSI_cf$Immune.cell <- rowSums(MSI_cf[, c("Lymphoid.cell", "Macrophage", "Mast.cell", "Myeloid.cell")])

#-------------------------------------------------------------------------------
# 2.1 add subtypes
#-------------------------------------------------------------------------------     

CIN_cf$subtype <- "CIN"
EBV_cf$subtype <- "EBV"
GS_cf$subtype <- "GS"
MSI_cf$subtype <- "MSI"

#-------------------------------------------------------------------------------
# 2.2 define major/minor celltypes
#-------------------------------------------------------------------------------

major_celltypes <- c("Endocrine.cell", "Endothelial.cell", "Epithelial.cell",
                     "Fibroblast", "Lymphoid.cell", "Macrophage",
                     "Mast.cell", "Myeloid.cell") #, "Immune.cell")

minor_celltypes <- c("CD4..T.cell", "CD8..T.cell", "DC", "Endocrine.cell",
                     "Endothelial.cell", "Epithelial.cell", "Macrophage.M1",
                     "Macrophage.M2", "Mast.cell", "Memory.B.cell", "Naive.B.cell", "NK.cell",
                     "Neutrophil", "Plasma.cell", "Treg", "iCAF", "myCAF")

#-------------------------------------------------------------------------------
# 2.3 reshape dataframes for plotting
#-------------------------------------------------------------------------------

# select cell types
CIN_cf_simple <- select(CIN_cf, all_of(major_celltypes))
EBV_cf_simple <- select(EBV_cf, all_of(major_celltypes))
GS_cf_simple <- select(GS_cf, all_of(major_celltypes))
MSI_cf_simple <- select(MSI_cf, all_of(major_celltypes))

# reshape the dataframes from wide to long format
CIN_long <- CIN_cf_simple %>% pivot_longer(cols = everything(),
                                           names_to = "Cell_Type", values_to = "Fraction")
EBV_long <- EBV_cf_simple %>% pivot_longer(cols = everything(),
                                           names_to = "Cell_Type", values_to = "Fraction")
GS_long <- GS_cf_simple %>% pivot_longer(cols = everything(),
                                           names_to = "Cell_Type", values_to = "Fraction")
MSI_long <- MSI_cf_simple %>% pivot_longer(cols = everything(),
                                           names_to = "Cell_Type", values_to = "Fraction")

# combine data
combined_df_simple <- bind_rows(
    mutate(CIN_long, subtype = "CIN"),
    mutate(EBV_long, subtype = "EBV"),
    mutate(GS_long, subtype = "GS"),
    mutate(MSI_long, subtype = "MSI")
)


if (cell_level == "cell_type2"){
    # select minor cell types for detailed model
    CIN_cf_detailed <- select(CIN_cf, all_of(minor_celltypes))
    EBV_cf_detailed <- select(EBV_cf, all_of(minor_celltypes))
    GS_cf_detailed <- select(GS_cf, all_of(minor_celltypes))
    MSI_cf_detailed <- select(MSI_cf, all_of(minor_celltypes))

    # reshape the dataframes from wide to long format
    CIN_long <- CIN_cf_detailed %>% pivot_longer(cols = everything(),
                                               names_to = "Cell_Type", values_to = "Fraction")
    EBV_long <- EBV_cf_detailed %>% pivot_longer(cols = everything(),
                                               names_to = "Cell_Type", values_to = "Fraction")
    GS_long <- GS_cf_detailed %>% pivot_longer(cols = everything(),
                                               names_to = "Cell_Type", values_to = "Fraction")
    MSI_long <- MSI_cf_detailed %>% pivot_longer(cols = everything(),
                                               names_to = "Cell_Type", values_to = "Fraction")

    # combine data
    combined_df_detailed <- bind_rows(
        mutate(CIN_long, subtype = "CIN"),
        mutate(EBV_long, subtype = "EBV"),
        mutate(GS_long, subtype = "GS"),
        mutate(MSI_long, subtype = "MSI")
    )
} else {
    combined_df_detailed <- NULL
}

   
#-------------------------------------------------------------------------------
# 3.0 plot cell fractions
#-------------------------------------------------------------------------------
# for output_simple
if (cell_level == "cell_type"){
    plot_name_simple <- "Estimated Cell Fractions by oncoBLADE simple model"
} else {
    plot_name_simple <- "Estimated Cell Fractions by oncoBLADE detailed model (cumulative)"
}


ggplot(combined_df_simple, aes(x = Cell_Type, y = Fraction, fill = subtype)) +
    geom_boxplot(position = position_dodge(width = 0.8)) +
    theme_minimal() +
    theme(axis.text.x = element_text(angle = 45, hjust = 1),
          panel.background = element_rect(fill = "white", color = "black"),
          plot.title = element_text(size = 12)) +
    labs(title = plot_name_simple, x = "Cell Type", y = "Fraction")
ggsave(output_simple)

# for output_detailed
if (cell_level == "cell_type2"){
    plot_name_detailed <- "Estimated Cell Fractions by oncoBLADE detailed model"

    ggplot(combined_df_detailed, aes(x = Cell_Type, y = Fraction, fill = subtype)) +
        geom_boxplot(position = position_dodge(width = 0.8)) +
        theme_minimal() +
        theme(axis.text.x = element_text(angle = 45, hjust = 1),
              panel.background = element_rect(fill = "white", color = "black"),
              plot.title = element_text(size = 12)) +
        labs(title = plot_name_detailed, x = "Cell Type", y = "Fraction")

    ggsave(output_detailed)
} else {
    ggplot() + theme_void() +
        ggtitle("Empty plot for cell_type")

    ggsave(output_detailed)
}

#-------------------------------------------------------------------------------
# 4.0 Plot normalized cell fractions
#-------------------------------------------------------------------------------

#-------------------------------------------------------------------------------
# 4.1 Normalization
#-------------------------------------------------------------------------------

# Exclude epithelial cell
norm_major <- major_celltypes[major_celltypes != "Epithelial.cell"]
norm_minor <- minor_celltypes[minor_celltypes != "Epithelial.cell"]

normalize_cf <- function(df, celltypes) {
    # Select only the cell type columns
    df_selected <- select(df, all_of(celltypes))
    
    # Calculate the row sums for each sample
    row_sums <- rowSums(df_selected)
    
    # Normalize each row by dividing by its row sum
    df_normalized <- sweep(df_selected, 1, row_sums, FUN = "/")
    
    # Convert from wide to long format
    df_long <- df_normalized %>%
        pivot_longer(cols = everything(),
                    names_to = "Cell_Type",
                    values_to = "Fraction")

    return(df_long)
}

# Apply normalization for each subtype and cell type
CIN_cf_norm_major <- normalize_cf(CIN_cf, norm_major)
EBV_cf_norm_major <- normalize_cf(EBV_cf, norm_major)
GS_cf_norm_major <- normalize_cf(GS_cf, norm_major)
MSI_cf_norm_major <- normalize_cf(MSI_cf, norm_major)

# combine data
combined_norm_simple <- bind_rows(
    mutate(CIN_cf_norm_major, subtype = "CIN"),
    mutate(EBV_cf_norm_major, subtype = "EBV"),
    mutate(GS_cf_norm_major, subtype = "GS"),
    mutate(MSI_cf_norm_major, subtype = "MSI")
)

if (cell_level == "cell_type2") {
    CIN_cf_norm_minor <- normalize_cf(CIN_cf, norm_minor)
    EBV_cf_norm_minor <- normalize_cf(EBV_cf, norm_minor)
    GS_cf_norm_minor <- normalize_cf(GS_cf, norm_minor)
    MSI_cf_norm_minor <- normalize_cf(MSI_cf, norm_minor)

    # combine data
    combined_norm_detailed <- bind_rows(
        mutate(CIN_cf_norm_minor, subtype = "CIN"),
        mutate(EBV_cf_norm_minor, subtype = "EBV"),
        mutate(GS_cf_norm_minor, subtype = "GS"),
        mutate(MSI_cf_norm_minor, subtype = "MSI")
    )
}

#-------------------------------------------------------------------------------
# 4.2 Plotting
#-------------------------------------------------------------------------------

# for output_norm_simple
if (cell_level == "cell_type"){
    plot_name_simple <- "Normalized Cell Fractions by oncoBLADE simple model"
} else {
    plot_name_simple <- "Normalized Cell Fractions by oncoBLADE detailed model (cumulative)"
}

# Perform pairwise Wilcoxon tests
stat_test <- combined_norm_simple %>%
    group_by(Cell_Type) %>%
    pairwise_wilcox_test(Fraction ~ subtype, p.adjust.method = "bonferroni") %>%
    add_xy_position(x = "Cell_Type") %>%
    add_significance()

# filter out non-significant results
sig_results <- stat_test[stat_test$p.adj.signif != "ns", ]

# significance level annotation
sig_legend_text <- data.frame(
    stars = c("****", "***", "**", "*"),
    meaning = c("p ≤ 0.0001", "p ≤ 0.001", "p ≤ 0.01", "p ≤ 0.05"),
    x = rep(7, 4),
    y = seq(0.9, 0.75, length.out = 4)
)

ggplot(combined_norm_simple, aes(x = Cell_Type, y = Fraction, fill = subtype)) +
    geom_boxplot(position = position_dodge(width = 0.8)) +
    geom_signif(xmin = sig_results$xmin, xmax = sig_results$xmax, annotations = sig_results$p.adj.signif,
                y_position = sig_results$y.position + 0.05,
                tip_length = 0.01, textsize = 2, size = 0.3) +
    annotate("text", x = sig_legend_text$x,
             y = sig_legend_text$y,
             label = paste(sig_legend_text$stars, sig_legend_text$meaning),
             hjust = 1,
             size = 3) +
    theme_bw() +
    theme(axis.text.x = element_text(angle = 45, hjust = 1),
          panel.background = element_rect(fill = "white", color = "black"),
          plot.title = element_text(size = 12)) +
    labs(title = plot_name_simple, x = "Cell Type", y = "Fraction")
ggsave(output_norm_simple)

# for output_norm_detailed
if (cell_level == "cell_type2"){
    plot_name_detailed <- "Normalized Cell Fractions by oncoBLADE detailed model"

    # Perform pairwise Wilcoxon tests
    stat_test <- combined_norm_detailed %>%
        group_by(Cell_Type) %>%
        pairwise_wilcox_test(Fraction ~ subtype, p.adjust.method = "bonferroni") %>%
        add_xy_position(x = "Cell_Type") %>%
        add_significance()

    # filter out non-significant results
    sig_results <- stat_test[stat_test$p.adj.signif != "ns", ]

    # significance level annotation
    sig_legend_text <- data.frame(
        stars = c("****", "***", "**", "*"),
        meaning = c("p ≤ 0.0001", "p ≤ 0.001", "p ≤ 0.01", "p ≤ 0.05"),
        x = rep(12, 4),
        y = seq(0.8, 0.65, length.out = 4)
    )

    ggplot(combined_norm_detailed, aes(x = Cell_Type, y = Fraction, fill = subtype)) +
        geom_boxplot(position = position_dodge(width = 0.8)) +
        geom_signif(xmin = sig_results$xmin, xmax = sig_results$xmax, annotations = sig_results$p.adj.signif,
                    y_position = sig_results$y.position + 0.05,
                    tip_length = 0.01, textsize = 2, size = 0.3) +
        annotate("text", x = sig_legend_text$x,
                 y = sig_legend_text$y,
                 label = paste(sig_legend_text$stars, sig_legend_text$meaning),
                 hjust = 1,
                 size = 3) +
        theme_bw() +
        theme(axis.text.x = element_text(angle = 45, hjust = 1),
              panel.background = element_rect(fill = "white", color = "black"),
              plot.title = element_text(size = 12)) +
        labs(title = plot_name_detailed, x = "Cell Type", y = "Fraction")

    ggsave(output_norm_detailed)
} else {
    ggplot() + theme_void() +
        ggtitle("Empty plot for cell_type")

    ggsave(output_norm_detailed)
}
