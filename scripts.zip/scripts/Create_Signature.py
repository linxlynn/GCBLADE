#!/usr/bin/python3
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# Create_Signature.py
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#
# Create cell type specific Signature Matrix
#
# Author: Jurriaan Janssen (j.janssen4@amsterdamumc.nl)
#
# Usage:
"""
python3 scripts/Create_Signature.py \
-i {input.adata_final} \
-o {output.adata_classified}
"""
#
# TODO:
# 1) Now all genes are used to create signature matrix: we want to use a DEG based selection
#    would be nice if command line argument gives DEG strategy as wildcard
# 2) Code is repetitive -> DONE
#
# History:
#  26-11-2021: File creation, write code
#  29-11-2021: Add Cancer cell subclassifications, Seperate minor/major celltypes
#  08-12-2021: Edits for adata_final
#  22-12-2021: Only include highly variable genes
#  11-05-2022: Edits for final_celltype
#  01-08-2022: Create signature in k-folds
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# 0.1  Import Libraries
#-------------------------------------------------------------------------------
import argparse
import scanpy as sc
import pickle
import numpy as np
import random
from utils import Get_fold_patients
#-------------------------------------------------------------------------------
# 1.1 Parse command line arguments
#-------------------------------------------------------------------------------
def parse_args():
    "Parse inputs from commandline and returns them as a Namespace object."
    parser = argparse.ArgumentParser(prog = 'python3 Create_Signature.py',
        formatter_class = argparse.RawTextHelpFormatter, description =
        '  Create celltype specific signature matrices  ')
    parser.add_argument('-i', help='path to input file',
                        dest='input',
                        type=str)
    parser.add_argument('-d', help='Major dataset to create signature for',
                        dest='dataset',
                        type=str,
                        default = 'All')
    parser.add_argument('-subtype', help='Subtype to create signature for',
                        dest='subtype',
                        choices = ["NSCLC","LUAD","LUSC"],
                        type=str,
                        default = "NSCLC")
    parser.add_argument('-celltypes', help='Celltypes to create signature for',
                        dest='celltype',
                        choices = ["cell_type","cell_type2"],
                        type=str)
    parser.add_argument('-fold', help='Cross validation fold to create signature for',
                        dest='fold',
                        type=int)
    parser.add_argument('-seed', help='Seed for random shuffling of patients',
                        dest='seed',
                        type=int,
                        default = 1)
    parser.add_argument('-o', help='path to output file',
                        dest='output',
                        type=str)
    args = parser.parse_args()
    return args

args = parse_args()


#-------------------------------------------------------------------------------
# 2.1 read Anndata object
#-------------------------------------------------------------------------------
print("Reading " + args.input + "...")
adata = sc.read_h5ad(args.input)
   
#-------------------------------------------------------------------------------
# 3.1 Calculate matrix dimensions
#-------------------------------------------------------------------------------
# fetch major or minor celltypes
celltypes = adata.obs[args.celltype].unique().tolist()

# create gene list
gene_list_total = adata.raw.var.index.tolist()
# create filtered gene list
gene_list_highly_variable = adata.var.index.tolist()
# only retain relevant dataset(s)
if args.dataset != "All":
    adata[adata.obs['dataset'] == args.dataset]
    
# calculate matrix dimensions
Ngenes = len(gene_list_total)
Ncelltypes = len(celltypes)

#-------------------------------------------------------------------------------
# 3.2 Fetch celltype abundances used for signature
#-------------------------------------------------------------------------------
# count number of obs per celltype and create dict
celltype_abundances = adata.obs.groupby(args.celltype).count().iloc[:,0].to_dict()

#-------------------------------------------------------------------------------
# 3.3 Calculate Mu and Omega
#-------------------------------------------------------------------------------
# initialize Mu: average gene expression per cell type
Mu = np.empty([Ngenes, Ncelltypes])
# initialize Omega: gene expression variability per cell type
Omega = np.empty([Ngenes, Ncelltypes])
# initialize Var: gene expression variance per cell type for correction later
Var = np.empty([Ngenes, Ncelltypes])

for celltype in celltypes:
    # obtain celltype data
    celltype_data = adata[adata.obs[args.celltype] == celltype]
    # obtain raw data
    raw_data = celltype_data.raw.X.toarray()
    # calculate mean expression
    expression_mean = raw_data.mean(axis = 0)
    # calculate standard deviation
    expression_variability = raw_data.std(axis = 0)
    # calculate variance
    expression_variance = raw_data.var(axis = 0)
    # fill in matrix
    Mu[:,celltypes.index(celltype)] = expression_mean
    Omega[:,celltypes.index(celltype)] = expression_variability
    Var[:,celltypes.index(celltype)] = expression_variance
#-------------------------------------------------------------------------------
# 3.5 Split to Major and Minor subtypes and Store
#-------------------------------------------------------------------------------
# Store results in dict
Signature_dict = {"Mu": Mu,
                  "Omega": Omega,
                  "Var": Var,
                  "Genelist": gene_list_total,
                  "GeneList_hvg": gene_list_highly_variable,
                  "celltype_list": celltypes,
                  "celltype_abundances" : celltype_abundances}

#-------------------------------------------------------------------------------
# 4.1 Write to file
#-------------------------------------------------------------------------------
with open(args.output, "wb") as out:
    pickle.dump(Signature_dict, out)
