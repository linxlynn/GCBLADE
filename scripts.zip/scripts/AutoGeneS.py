#!/usr/bin/python3
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# AutoGeneS.py
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#
# Find top discriminative genes with AutoGeneS
#
# Author: Jurriaan Janssen (j.janssen4@amsterdamumc.nl)
#
# Usage:
"""
python3 scripts/Phenotype_clusters.py \ 
-i {input.adata_extended} \
-level {wildcards.celltype_level} \
-o {output.adata_ranked}
"""
#
# TODO:
# 1)
#
# History:
#  24-10-2022: File creation, write code
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# 0.1  Import Libraries
#-------------------------------------------------------------------------------
import sys
print("rule AutoGeneS")
print(sys.prefix)
import scanpy as sc
import autogenes as ag
import argparse
import pandas as pd
import numpy as np
from utils import Retain_raw_highly_variable

#-------------------------------------------------------------------------------
# 1.1 Parse command line arguments
#-------------------------------------------------------------------------------
def parse_args():
    "Parse inputs from commandline and returns them as a Namespace object."
    parser = argparse.ArgumentParser(prog = 'python3 Phenotype_clusters.py',
        formatter_class = argparse.RawTextHelpFormatter, description =
        '  Phenotype clusters based on canonical markers  ')
    parser.add_argument('-i', help='path to input file',
                        dest='input',
                        type=str)
    parser.add_argument('-level', help='celltype level',
                        dest='celltype_level',
                        type=str)
    parser.add_argument('-o', help='path to output file',
                        dest='output',
                        type=str)
    args = parser.parse_args()
    return args

args = parse_args()
#-------------------------------------------------------------------------------
# 2.1 read data
#-------------------------------------------------------------------------------
adata = sc.read_h5ad(args.input)

#-------------------------------------------------------------------------------
# 3.1 Calculate centroids of cell types
#-------------------------------------------------------------------------------
celltypes = adata.obs[args.celltype_level].unique()
sc_mean = pd.DataFrame(index=pd.Index(adata.var.index),columns=celltypes)
adata.raw = adata.raw[:,adata.raw.var["vst.variable"] == 1].to_adata()

for celltype in celltypes:
    adata_filtered = adata[adata.obs[args.celltype_level] == celltype]
    sc_part = adata_filtered.raw.X.T
    sc_mean[celltype] = pd.DataFrame(np.mean(sc_part,axis=1),index=pd.Index(adata.var.index))
    
centroids_sc_hv = sc_mean
print("printing centroids")
print(centroids_sc_hv)
#-------------------------------------------------------------------------------
# 3.2 Run AutoGeneS
#-------------------------------------------------------------------------------
ag.init(centroids_sc_hv.T)
ag.optimize(ngen=5000,seed=0, offspring_size=100,verbose=False)

index = ag.select(index=0)
centroids_sc_pareto = centroids_sc_hv[index]
print(centroids_sc_pareto)

#-------------------------------------------------------------------------------
# 3.2 write to file
#-------------------------------------------------------------------------------
centroids_sc_pareto.to_csv(args.output, sep = '\t')
