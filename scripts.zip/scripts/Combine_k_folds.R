#!/usr/bin/env Rscript
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# Combine_k_folds.R
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#
# after running k fold oncoBLADE runs, combine all estimated cf into one dataframe
#
# Author: Florenz van Otterloo (f.j.w.vanotterloo@amsterdamumc.nl)
#
# Usage:
# R Combine_k_folds.R
#
# TODO:
# 
# History:
# 23-06-2024: 
# 13-11-2024: adapt to Snakemake pipeline (Xinyu)
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# 0.1  Import Libraries
#-------------------------------------------------------------------------------

suppressMessages({
    library(dplyr)
    library(argparse)
})

#-------------------------------------------------------------------------------
# 1.0 Parse arguments
#-------------------------------------------------------------------------------
parser <- ArgumentParser()

# Add arguments
parser$add_argument("--cf_file", type = "character", nargs = "+", help = "Provide paths to files containing cell fractions")
parser$add_argument("--metrics", type = "character", nargs = "+", help = "Provide paths to files containing metrics")
parser$add_argument("--if_STAD", type = "character", default = "NO", help = "Define whether dataset subtype is STAD")
parser$add_argument("--subtype_file", type = "character", help = "Provide path to subtype corrected file")
parser$add_argument("--output_comb", type = "character", help = "Provide path to combined file")
parser$add_argument("--output_norm", type = "character", help = "Provide path to normalized file")
parser$add_argument("--output_obj", type = "character", help = "Provide path to combined obj_fun file")

# Parse arguments
args <- parser$parse_args()

cf <- args$cf_file
metrics <- args$metrics
if_STAD <- args$if_STAD
subtype_file <- args$subtype_file
output_comb <- args$output_comb
output_norm <- args$output_norm
output_obj <- args$output_obj

#-------------------------------------------------------------------------------
# 2.0 Combine OncoBLADE output
#-------------------------------------------------------------------------------

subtype_full <- read.csv(subtype_file)

combined_data <- NULL

# Loop through each file path
for (file_path in cf) {
    # Extract the k fold number from file name
    match <- regmatches(file_path, regexec("\\.k([0-9]+)\\.csv", file_path))
    k_value <- as.numeric(match[[1]][2])
    
    # Read the CSV file
    df <- read.csv(file_path)
    
    df$k <- k_value

    # if data given is STAD file, add subtype info
    if (if_STAD == "YES") {
        subtype_full$barcode <- gsub("-", ".", subtype_full$Patient.ID)
        subtype_full$subtype <- gsub("STAD_", "", subtype_full$Subtype)
        df$subtype <- subtype_full$subtype[match(df$barcode, subtype_full$barcode)]
    }
    
    # Append the data
    if (is.null(combined_data)) {
        combined_data <- df
    } else {
        combined_data <- rbind(combined_data, df)
    }

    
}
        
# Write output
write.csv(combined_data, file = output_comb, row.names = FALSE)

#-------------------------------------------------------------------------------
# 3.0 Normalization
#-------------------------------------------------------------------------------

numeric_cols <- names(select_if(combined_data, is.numeric))
numeric_cols <- setdiff(numeric_cols, c("Epithelial.cell", "k", "tumor_percentage", "tumor_percentage_estimated")) # exclude epithelial and k

norm_data <- combined_data %>%
    mutate(row_sum = rowSums(select(., all_of(numeric_cols)))) %>%
    mutate(across(all_of(numeric_cols), ~./row_sum)) %>%
    select(-row_sum)


# Write output
write.csv(norm_data, file = output_norm, row.names = FALSE)

#-------------------------------------------------------------------------------
# 4.0 Combine obj_fun of k folds
#-------------------------------------------------------------------------------

comb_obj <- NULL

for (file_path in metrics) {
    match <- regmatches(file_path, regexec("\\.k([0-9]+)\\.csv", file_path))
    k_value <- as.numeric(match[[1]][2])

    # Read the CSV file
    df <- read.csv(file_path)
    df <- df[!colnames(df) %in% c("log", "iterations")]
    df$k <- k_value


    if (is.null(comb_obj)) {
        comb_obj <- df
    } else {
        comb_obj <- rbind(comb_obj, df)
    }
}

# Write output
write.csv(comb_obj, file = output_obj, row.names = FALSE)

