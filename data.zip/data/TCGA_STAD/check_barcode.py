import pandas as pd
from itertools import combinations

#----------------------------------------------------------------------------------------------------------------------------------
# check the number of overlapping barcodes between Subtype.full.corrected.csv and nationwidechildrens.org_clinical_patient_stad.txt
#----------------------------------------------------------------------------------------------------------------------------------

# Load the files
clinical = pd.read_csv('nationwidechildrens.org_clinical_patient_stad.txt', sep = '\t', header = 0, skiprows = [1,2])
subtype_corr = pd.read_csv('Subtype.full.corrected.csv')

# select only non-metastatic patients in clinical_patient
clinical_patient = clinical[clinical['ajcc_metastasis_pathologic_pm'] == 'M0']

# select patient ID
barcode = set(clinical_patient['bcr_patient_barcode'])
patient_ID = set(subtype_corr['Patient.ID'])

overlap = barcode.intersection(patient_ID)

print(f"Number of overlapping patients between clinical patient file and subtype corrected file: {len(overlap)}")

# Filter subtype_corr to only include overlapping patients
subtype_corr_filtered = subtype_corr[subtype_corr['Patient.ID'].isin(overlap)]

# Check number of patients in each subtype
MSI = subtype_corr_filtered[subtype_corr_filtered['Subtype'] == 'STAD_MSI']
EBV = subtype_corr_filtered[subtype_corr_filtered['Subtype'] == 'STAD_EBV']
CIN = subtype_corr_filtered[subtype_corr_filtered['Subtype'] == 'STAD_CIN']
GS = subtype_corr_filtered[subtype_corr_filtered['Subtype'] == 'STAD_GS']

print(f"MSI: {len(MSI)}; EBV: {len(EBV)}; CIN: {len(CIN)}; GS: {len(GS)}")

#----------------------------------------------------------------------------------------------------------------
# CIN subtype drops from 23 to 22 after subtype correction
# to make sure that it is corrected to MSI
# check overlap of patients between CIN subtype in Subtype.full.txt and MSI subtype in Subtype.full.corrected.csv
#----------------------------------------------------------------------------------------------------------------

# Load orginal subtype file
subtype_full = pd.read_csv('Subtype.full.txt', sep = '\t')

# Select the CIN subtypes
subtype_CIN = subtype_full[subtype_full['Subtype'] == 'STAD_CIN']

# Get patient ID for CIN subtypes from original file
patient_CIN = set(subtype_CIN['Patient ID'])


# Get MSI patients from corrected subtype file
subtype_MSI = subtype_corr[subtype_corr['Subtype'] == 'STAD_MSI']
patient_MSI = set(subtype_MSI['Patient.ID'])

overlap_2 = patient_CIN.intersection(patient_MSI)

#print(f"Number of overlapping patients between CIN from original subtype file and MSI from corrected subtype file: {len(overlap_2)}")

#------------------------------
# check overlap between 4 files
#------------------------------

# Load gdc data
gdc = pd.read_csv('raw_counts/RNAseq_data/gdc_sample_sheet.2024-03-01.tsv', sep = '\t')

# Select primary tumors
gdc_pm = gdc[gdc['Sample Type'] == 'Primary Tumor']

# Get patient ID
gdc_patient = set(gdc_pm['Case ID'])


# Load ace data
ace = pd.read_csv('raw_counts/bulk/ACE_samplesheet.txt', sep = '\t')

# Get patient ID
ace_patient = set(ace['sample'])

overlap_3 = ace_patient.intersection(patient_ID, barcode, gdc_patient)

print(f"Number of overlapping patients between 4 files: {len(overlap_3)}")


# print a chosen file's columns
#print("columns:", subtype_corr.columns.tolist())


#---------------------------------------------------
# Check missing patients from overlapping of 4 files
#---------------------------------------------------

def consolidated_missing_pat(subtype_df, clinical_df, gdc_df, ace_df):
    """
    Analyze missing patients from each file
    Create a single consolidated CSV file
    
    Parameters:
    ace_df: DataFrame of ACE sample sheet
    subtype_df: DataFrame of subtype corrected file
    clinical_df: DataFrame of clinical patient file
    gdc_df: DataFrame of GDC sample sheet
    """
    # Extract patient sets
    ace_patient = set(ace_df['sample'])
    patient_ID = set(subtype_df['Patient.ID'])
    barcode = set(clinical_df['bcr_patient_barcode'])
    gdc_patient = set(gdc_df['Case ID'])
    
    # Create a dictionary of all sets and their corresponding DataFrames
    sets = {
        'ACE': {'set': ace_patient, 'df': ace_df, 'id_col': 'sample'},
        'Subtype': {'set': patient_ID, 'df': subtype_df, 'id_col': 'Patient.ID'},
        'Clinical': {'set': barcode, 'df': clinical_df, 'id_col': 'bcr_patient_barcode'},
        'GDC': {'set': gdc_patient, 'df': gdc_df, 'id_col': 'Case ID'}
    }

    # Calculate file lengths
    sample_counts = {
        'ACE_samples': len(ace_patient),
        'Subtype samples corrected': len(patient_ID),
        'Clinical samples without metastasis': len(barcode),
        'GDC samples without normal solid tissue': len(gdc_patient)
    }
    
    # Initialize
    missing_patients_data = []
    
    # Find patients missing from each file
    for target_name, target_data in sets.items():
        # Create union of all other sets
        other_sets = {k: v for k, v in sets.items() if k != target_name}
        all_other_patients = set.union(*[v['set'] for v in other_sets.values()])
        
        # Find patients that exist in other files but not in this one
        missing_in_target = all_other_patients - target_data['set']
        
        # For each missing patient, find which files they appear in
        for patient in missing_in_target:
            patient_info = {
                'Patient_ID': patient,
                'Missing_From': target_name,
                'Present_In': []
            }
            
            # Check which other files contain this patient
            for other_name, other_data in other_sets.items():
                if patient in other_data['set']:
                    patient_info['Present_In'].append(other_name)
                    
                    # Add relevant information from the file that has this patient
                    patient_df = other_data['df'][other_data['df'][other_data['id_col']] == patient]
                    
                    # Add file-specific information
                    if other_name == 'ACE':
                        if 'ACE' in patient_df.columns:
                            patient_info['ACE'] = patient_df['ACE'].iloc[0]
                    elif other_name == 'Subtype':
                        if 'Subtype' in patient_df.columns:
                            patient_info['Subtype'] = patient_df['Subtype'].iloc[0]
                    elif other_name == 'Clinical':
                        if 'ajcc_metastasis_pathologic_pm' in patient_df.columns:
                            patient_info['Clinical_Stage'] = patient_df['ajcc_metastasis_pathologic_pm'].iloc[0]
                    elif other_name == 'GDC':
                        if 'Sample Type' in patient_df.columns:
                            patient_info['GDC_Sample_Type'] = patient_df['Sample Type'].iloc[0]
            
            patient_info['Present_In'] = ', '.join(patient_info['Present_In'])
            missing_patients_data.append(patient_info)
    
    # Create DataFrame from collected data
    missing_df = pd.DataFrame(missing_patients_data)
    
    # Sort by Patient_ID and Missing_From for better readability
    missing_df = missing_df.sort_values(['Patient_ID', 'Missing_From'])

    # Export to CSV
    output_file = 'consolidated_missing_patients.csv'
    missing_df.to_csv(output_file, index=False)

    # Print df lengths
    print(sample_counts)
    
    # Print summary
    print("Missing Patients Summary:")
    print("------------------------")
    for file_name in sets.keys():
        missing_count = len(missing_df[missing_df['Missing_From'] == file_name])
        print(f"Patients missing from {file_name}: {missing_count}")
    
    print(f"Detailed information exported to {output_file}")
    return missing_df

missing_patients = consolidated_missing_pat(subtype_corr, clinical_patient, gdc_pm, ace)

missing_ID = set(missing_patients['Patient_ID'])
print(f"Number of unique patients with missing data: {len(missing_ID)}")

all_patients = ace_patient | patient_ID | barcode | gdc_patient
total_unique_patients = len(all_patients)
print("Total unique patients in all 4 files:", total_unique_patients)
