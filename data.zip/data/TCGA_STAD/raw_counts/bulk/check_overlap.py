import pandas as pd

# Load the files
STAD = pd.read_csv('STAD/ALL/samplesheet.txt', sep='\t')
MSI = pd.read_csv('MSI/ALL/samplesheet.txt', sep='\t')
EBV = pd.read_csv('EBV/ALL/samplesheet.txt', sep='\t')
GS = pd.read_csv('GS/ALL/samplesheet.txt', sep='\t')
CIN = pd.read_csv('CIN/ALL/samplesheet.txt', sep='\t')

datasets = {'MSI': MSI, 'EBV': EBV, 'GS': GS, 'CIN': CIN}
STAD_count = STAD.shape[0]
print(f"Number of samples in STAD: {STAD_count}")

# Check overlaps for each dataset with STAD
for name, df in datasets.items():
    subtype_count = df.shape[0]
    overlap = pd.merge(STAD[['sample']], df[['sample']], on='sample')
    overlap_count = overlap.shape[0]
    print(f"Number of samples in {name}: {subtype_count}")
    print(f"Number of overlapping samples with {name}: {overlap_count}")
